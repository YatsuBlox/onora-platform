import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? "admin@onora.com.br";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "TrocarSenha123";

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      fullName: "Administrador ONORA",
      email: adminEmail,
      phone: "(00) 00000-0000",
      cpf: "00000000000",
      passwordHash,
      role: "ADMIN",
    },
  });

  console.log("Usuário admin pronto:");
  console.log(`  e-mail: ${admin.email}`);
  console.log(`  senha:  ${adminPassword}  (troque assim que fizer o primeiro login)`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

# ONORA — Plataforma de eventos

Código de produção da plataforma de eventos e ingressos da ONORA PRODUÇÕES.

## Status do projeto

Este repositório está sendo construído em fases. **Fase 1 (atual): autenticação
e banco de dados** — totalmente funcional. As próximas fases (catálogo de
eventos, checkout/Mercado Pago/ingressos com QR Code, e painel admin) serão
adicionadas por cima desta base, sem quebrar o que já existe.

O que já funciona de ponta a ponta nesta fase:

- Cadastro de conta (nome, e-mail, telefone, CPF com validação real, senha)
- Login com sessão persistente (JWT em cookie `httpOnly`)
- Logout
- Recuperação de senha por e-mail (token de uso único, expira em 1h)
- Proteção de rotas (`/dashboard`, `/admin`) via middleware
- Página `/dashboard` real, protegida, mostrando os dados do usuário logado

O que **ainda não existe** (vem nas próximas fases): catálogo de eventos,
compra de ingresso, checkout do Mercado Pago, QR Code, e painel
administrativo.

## Stack

- **Frontend + Backend**: Next.js 14 (App Router) + TypeScript
- **Banco de dados**: PostgreSQL via Prisma ORM
- **Autenticação**: JWT (`jose`) em cookie `httpOnly`, senhas com `bcryptjs`
- **Validação**: Zod (inclui validação real de CPF, com dígitos verificadores)
- **Estilo**: Tailwind CSS

## Rodando localmente

### 1. Pré-requisitos

- Node.js 20+
- Uma URL de banco Postgres. O jeito mais simples e gratuito para começar é
  criar um banco na [Neon](https://neon.tech) (leva 2 minutos, não precisa
  cartão de crédito).

### 2. Instalar dependências

```bash
npm install
```

### 3. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite o `.env` e preencha pelo menos:

- `DATABASE_URL` e `DIRECT_URL` — a connection string do seu banco (a Neon
  te dá as duas; se seu provedor só tiver uma, use o mesmo valor nas duas)
- `JWT_SECRET` — gere um valor forte com `openssl rand -base64 48`

O restante (`RESEND_API_KEY`, Mercado Pago) pode ficar em branco por agora —
sem `RESEND_API_KEY`, os e-mails de recuperação de senha são apenas
impressos no console do servidor, o que já é suficiente para testar o fluxo
em desenvolvimento.

### 4. Criar as tabelas no banco

```bash
npx prisma migrate dev --name init
```

Isso cria todas as tabelas (inclusive as de eventos/ingressos, que ainda não
têm API — elas só passam a ser usadas nas próximas fases).

### 5. (Opcional) Criar um usuário admin de teste

```bash
npm run db:seed
```

Isso cria `admin@onora.com.br` / `TrocarSenha123` (ou os valores de
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD`, se você definir essas variáveis).
Troque a senha assim que possível — este comando é só para desenvolvimento.

### 6. Rodar

```bash
npm run dev
```

Abra `http://localhost:3000`. Crie uma conta em `/criar-conta`, faça login
em `/entrar`, e veja o `/dashboard` protegido funcionando com o banco real.

### Checagem de tipos

```bash
npm run typecheck
```

## Deploy (Vercel + Neon) — sugestão mais simples

1. Suba este código para um repositório no GitHub.
2. Crie um banco na [Neon](https://neon.tech), copie as connection strings
   (pooled → `DATABASE_URL`, direct → `DIRECT_URL`).
3. Importe o repositório na [Vercel](https://vercel.com/new).
4. Em "Environment Variables", adicione `DATABASE_URL`, `DIRECT_URL` e
   `JWT_SECRET` (e depois `RESEND_API_KEY`/Mercado Pago, quando chegar a
   hora).
5. Rode as migrações contra o banco de produção uma vez, a partir da sua
   máquina, apontando o `.env` local para a `DATABASE_URL` de produção:
   ```bash
   npx prisma migrate deploy
   ```
6. Deploy. Pronto — `/entrar`, `/criar-conta`, `/dashboard` já funcionam de
   verdade em produção.

## Estrutura do projeto

```
prisma/
  schema.prisma      # modelo completo do banco (users, events, batches, orders, tickets)
  seed.ts             # cria um admin de teste
src/
  app/
    api/auth/         # rotas de autenticação (signup, login, logout, me, forgot/reset password)
    (auth)/           # páginas de entrar / criar conta / recuperar / redefinir senha
    dashboard/        # página protegida (prova de sessão funcionando)
    layout.tsx
    page.tsx          # home provisória desta fase
  components/ui/       # componentes visuais reutilizados (Field, botões, etc.)
  lib/
    prisma.ts          # cliente Prisma singleton
    auth.ts             # emissão/verificação de JWT + cookies
    session.ts          # helpers de sessão para Server Components (requireAuth, requireAdmin)
    password.ts          # hash de senha e tokens de recuperação
    validation.ts          # schemas Zod (inclui validação real de CPF)
    email.ts                # abstração de envio de e-mail
    safe-user.ts              # remove o hash de senha antes de responder à API
  middleware.ts               # protege /dashboard e /admin
```

## Notas de segurança para revisar antes do lançamento

- **Rate limiting**: os endpoints de login/signup/forgot-password ainda não
  têm limite de tentativas. Antes de lançar, adicione um rate limiter (ex:
  [Upstash Ratelimit](https://github.com/upstash/ratelimit), que funciona
  bem com Vercel/Edge) para evitar força bruta.
- **E-mail transacional**: configure um provedor de verdade (`RESEND_API_KEY`
  ou outro) antes do lançamento — sem isso, a recuperação de senha não
  chega ao usuário.
- **JWT_SECRET**: use um valor gerado aleatoriamente (nunca o placeholder do
  `.env.example`) e nunca o exponha publicamente.
- **CPF**: a validação confirma que o CPF é matematicamente válido, mas não
  confirma que pertence à pessoa que está se cadastrando (isso exigiria
  verificação com a Receita Federal ou um serviço terceirizado, fora do
  escopo desta fase).

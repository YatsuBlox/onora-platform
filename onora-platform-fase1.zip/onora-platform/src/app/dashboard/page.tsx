import { getCurrentUser } from "@/lib/session";
import { Wordmark } from "@/components/ui/wordmark";
import { LogoutButton } from "@/components/ui/logout-button";

// A rota /dashboard já é protegida pelo middleware (src/middleware.ts), que
// redireciona para /entrar se não houver sessão válida. Ainda assim,
// buscamos o usuário aqui para exibir os dados reais e para o caso (raro)
// de a sessão ter sido revogada entre o middleware e o carregamento da
// página (ex: usuário excluído).
export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    // Este caso não deveria ocorrer com o middleware ativo, mas evitamos
    // quebrar a página caso aconteça.
    return (
      <main className="min-h-screen flex items-center justify-center text-white/50 text-sm">
        Sessão expirada.
      </main>
    );
  }

  return (
    <main className="min-h-screen px-6 py-16 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-16">
        <Wordmark size="text-lg" />
        <LogoutButton />
      </div>

      <h1 className="font-display text-3xl text-white mb-2">Olá, {user.fullName.split(" ")[0]}</h1>
      <p className="text-white/40 text-sm mb-12">{user.email}</p>

      <div className="border border-white/10 p-6 space-y-3 text-sm">
        <div className="flex justify-between border-b border-white/10 pb-3">
          <span className="text-white/40 uppercase tracking-wide text-[11px] pt-0.5">Nome</span>
          <span className="text-white">{user.fullName}</span>
        </div>
        <div className="flex justify-between border-b border-white/10 pb-3">
          <span className="text-white/40 uppercase tracking-wide text-[11px] pt-0.5">Telefone</span>
          <span className="text-white">{user.phone}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-white/40 uppercase tracking-wide text-[11px] pt-0.5">Papel</span>
          <span className="text-white">{user.role === "ADMIN" ? "Administrador" : "Cliente"}</span>
        </div>
      </div>

      <p className="text-white/25 text-xs mt-10">
        Próximos ingressos, pedidos e histórico de eventos chegam na Fase 2/3 deste
        projeto — por enquanto, esta página só prova que login, sessão e proteção de
        rota estão funcionando de ponta a ponta com o banco de dados real.
      </p>
    </main>
  );
}

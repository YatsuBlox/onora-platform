import Link from "next/link";
import { Wordmark } from "@/components/ui/wordmark";
import { primaryButtonClass, ghostButtonClass } from "@/components/ui/buttons";

// Home provisória da Fase 1 (autenticação + banco). A home completa com
// hero de evento, cards e histórico é implementada na Fase 2.
export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <Wordmark size="text-3xl" />
      <p className="text-white/40 text-sm mt-6 max-w-xs">
        A plataforma de eventos está em construção. Cadastro e login já
        funcionam de verdade.
      </p>
      <div className="flex gap-3 mt-10">
        <Link href="/entrar" className={ghostButtonClass}>
          Entrar
        </Link>
        <Link href="/criar-conta" className={primaryButtonClass}>
          Criar conta
        </Link>
      </div>
    </main>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { AUTH_COOKIE_NAME, verifyAuthToken, type AuthPayload } from "@/lib/auth";
import { jsonError } from "@/lib/api-response";

type AdminAuthResult = { payload: AuthPayload } | { errorResponse: NextResponse };

// Usado no início de API routes administrativas. Diferente de
// `requireAdmin()` (usado em Server Components, que redireciona), aqui
// devolvemos uma resposta JSON de erro — é isso que um cliente de API
// espera receber, não um redirecionamento de página.
export async function requireAdminFromRequest(request: NextRequest): Promise<AdminAuthResult> {
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;
  if (!token) {
    return { errorResponse: jsonError("Não autenticado", 401) };
  }

  const payload = await verifyAuthToken(token);
  if (!payload) {
    return { errorResponse: jsonError("Não autenticado", 401) };
  }

  if (payload.role !== "ADMIN") {
    return { errorResponse: jsonError("Acesso restrito a administradores", 403) };
  }

  return { payload };
}

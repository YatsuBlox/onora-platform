import { z } from "zod";

// --- CPF ---------------------------------------------------------

// Remove tudo que não for dígito.
function onlyDigits(value: string): string {
  return value.replace(/\D/g, "");
}

// Implementação padrão do algoritmo de validação de CPF (dois dígitos
// verificadores). Rejeita CPFs com todos os dígitos iguais (ex:
// "111.111.111-11"), que passam na fórmula mas nunca são válidos na prática.
export function isValidCPF(rawValue: string): boolean {
  const cpf = onlyDigits(rawValue);
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;

  const digits = cpf.split("").map(Number);

  const calcCheckDigit = (length: number): number => {
    let sum = 0;
    for (let i = 0; i < length; i++) {
      sum += digits[i]! * (length + 1 - i);
    }
    const remainder = (sum * 10) % 11;
    return remainder === 10 ? 0 : remainder;
  };

  const firstCheck = calcCheckDigit(9);
  const secondCheck = calcCheckDigit(10);

  return firstCheck === digits[9] && secondCheck === digits[10];
}

const cpfSchema = z
  .string()
  .transform(onlyDigits)
  .refine((value) => value.length === 11, "CPF deve ter 11 dígitos")
  .refine(isValidCPF, "CPF inválido");

const phoneSchema = z
  .string()
  .transform(onlyDigits)
  .refine((value) => value.length >= 10 && value.length <= 11, "Telefone inválido");

// Senha: mínimo 8 caracteres, pelo menos uma letra e um número. Ajuste essa
// política com o time de segurança antes do lançamento, se necessário.
const passwordSchema = z
  .string()
  .min(8, "A senha precisa ter pelo menos 8 caracteres")
  .regex(/[a-zA-Z]/, "A senha precisa conter pelo menos uma letra")
  .regex(/[0-9]/, "A senha precisa conter pelo menos um número");

export const signupSchema = z.object({
  fullName: z.string().trim().min(3, "Informe o nome completo"),
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
  phone: phoneSchema,
  cpf: cpfSchema,
  password: passwordSchema,
});
export type SignupInput = z.infer<typeof signupSchema>;

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
  password: z.string().min(1, "Informe a senha"),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
});
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Token ausente"),
  password: passwordSchema,
});
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;

// --- Eventos (Fase 2) ---------------------------------------------

const batchInputSchema = z.object({
  id: z.string().optional(), // presente ao editar um lote existente; ausente = novo lote
  name: z.string().trim().min(1, "Informe o nome do lote"),
  price: z.coerce.number().min(0, "Preço inválido"),
  totalQuantity: z.coerce.number().int().min(0, "Quantidade inválida"),
});

export const eventInputSchema = z.object({
  name: z.string().trim().min(3, "Informe o nome do evento"),
  tagline: z.string().trim().optional().default(""),
  description: z.string().trim().optional().default(""),
  bannerUrl: z
    .string()
    .trim()
    .optional()
    .default("")
    .refine((value) => value === "" || /^https?:\/\//.test(value), "URL do banner inválida"),
  // Vem de um <input type="datetime-local">, sem timezone — interpretamos
  // no fuso do servidor ao converter para Date no endpoint.
  date: z.string().min(1, "Informe a data e horário"),
  venue: z.string().trim().min(1, "Informe o local"),
  address: z.string().trim().optional().default(""),
  attractions: z.array(z.string().trim()).default([]),
  info: z.string().trim().optional().default(""),
  status: z.enum(["DRAFT", "ACTIVE", "FINISHED", "CANCELED"]),
  isHero: z.boolean().default(false),
  batches: z.array(batchInputSchema).default([]),
});
export type EventInput = z.infer<typeof eventInputSchema>;

import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { EventVisual } from "@/components/events/event-visual";
import { formatDateFull, formatMoney, formatTime } from "@/lib/format";

export const dynamic = "force-dynamic";

type EventPageProps = { params: { slug: string } };

export default async function EventPage({ params }: EventPageProps) {
  const event = await prisma.event.findUnique({
    where: { slug: params.slug },
    include: { batches: { orderBy: { createdAt: "asc" } } },
  });

  // Rascunhos não são públicos, e um slug inexistente vira 404 normal.
  if (!event || event.status === "DRAFT") {
    notFound();
  }

  const soldOut = event.batches.every((b) => b.soldQuantity >= b.totalQuantity);
  const minPrice = event.batches.length > 0 ? Math.min(...event.batches.map((b) => Number(b.price))) : null;

  const statusLabel: Record<string, string> = {
    ACTIVE: "ativo",
    FINISHED: "finalizado",
    CANCELED: "cancelado",
    DRAFT: "rascunho",
  };

  return (
    <div>
      <div className="relative h-[62vh] min-h-[400px] w-full overflow-hidden">
        <EventVisual seed={event.id} bannerUrl={event.bannerUrl} />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/40" />
        <div className="absolute bottom-10 md:bottom-14 left-0 right-0 max-w-7xl mx-auto px-5 md:px-8">
          <span className="text-[11px] uppercase tracking-[0.12em] text-white/60">
            {statusLabel[event.status]}
          </span>
          <h1 className="font-display text-[13vw] md:text-7xl leading-[0.9] text-white mt-4">
            {event.name}
          </h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 md:px-8 py-14 md:py-20 grid md:grid-cols-3 gap-12 md:gap-16">
        <div className="md:col-span-2 space-y-12">
          <div className="flex flex-wrap gap-x-6 gap-y-3 pb-8 border-b border-white/10 text-white/55 text-sm">
            <span>{formatDateFull(event.date)}</span>
            <span>{formatTime(event.date)}</span>
            <span>{event.venue}</span>
          </div>

          {(event.tagline || event.address) && (
            <p className="text-white/70 text-[16px] leading-relaxed max-w-lg">
              {event.tagline}
              {event.tagline && event.address ? ". " : ""}
              {event.address}
            </p>
          )}

          {event.description && (
            <p className="text-white/60 text-sm leading-relaxed max-w-lg whitespace-pre-line">
              {event.description}
            </p>
          )}

          {event.attractions.length > 0 && (
            <div>
              <div className="text-[11px] uppercase tracking-[0.2em] text-white/40 mb-4">Atrações</div>
              <div className="space-y-0">
                {event.attractions.map((attraction, i) => (
                  <div key={attraction} className="flex items-baseline gap-4 py-3 border-b border-white/10">
                    <span className="text-[11px] text-white/30 tabular-nums">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="font-display text-lg md:text-xl text-white">{attraction}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {event.info && (
            <div>
              <div className="text-[11px] uppercase tracking-[0.2em] text-white/40 mb-3">
                Informações importantes
              </div>
              <p className="text-sm text-white/55 leading-relaxed max-w-lg whitespace-pre-line">
                {event.info}
              </p>
            </div>
          )}
        </div>

        <div className="md:sticky md:top-28 h-fit">
          <div className="text-[11px] uppercase tracking-[0.2em] text-white/40 mb-5">Ingressos</div>
          {event.batches.length === 0 ? (
            <p className="text-white/30 text-sm">Nenhum lote cadastrado ainda.</p>
          ) : (
            <div className="space-y-0 mb-8">
              {event.batches.map((batch) => {
                const left = batch.totalQuantity - batch.soldQuantity;
                return (
                  <div key={batch.id} className="flex items-center justify-between py-4 border-b border-white/10">
                    <div>
                      <div className="text-[15px] text-white">{batch.name}</div>
                      <div className="text-[12px] text-white/35">
                        {left > 0 ? `${left} disponíveis` : "esgotado"}
                      </div>
                    </div>
                    <div className="text-[15px] text-white tabular-nums">{formatMoney(Number(batch.price))}</div>
                  </div>
                );
              })}
            </div>
          )}

          {event.status === "ACTIVE" && !soldOut && event.batches.length > 0 && (
            <div className="border border-white/10 px-4 py-3 text-xs text-white/40">
              A compra de ingressos chega na próxima fase deste projeto — por
              enquanto, esta página mostra os lotes e preços reais vindos do
              banco de dados.
            </div>
          )}
          {soldOut && event.batches.length > 0 && (
            <div className="border border-white/10 px-4 py-3 text-xs text-white/40">Esgotado</div>
          )}
        </div>
      </div>

      {minPrice !== null && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black/95 backdrop-blur border-t border-white/10 px-5 py-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase tracking-wide text-white/40">A partir de</div>
            <div className="text-lg text-white font-display">{formatMoney(minPrice)}</div>
          </div>
        </div>
      )}
    </div>
  );
}

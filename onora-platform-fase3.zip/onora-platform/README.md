# ONORA — Plataforma de eventos

Código de produção da plataforma de eventos e ingressos da ONORA PRODUÇÕES.

## Status do projeto

Este repositório está sendo construído em fases. **Fases 1, 2 e 3 já estão
concluídas e funcionando de verdade.** A próxima fase (o restante do painel
admin — vendas, ingressos, venda manual, dashboard de faturamento) será
adicionada por cima desta base, sem quebrar o que já existe.

O que já funciona de ponta a ponta:

**Fase 1 — Autenticação**
- Cadastro, login, logout, recuperação de senha, sessão JWT em cookie
  `httpOnly`, proteção de rotas, `/dashboard` real

**Fase 2 — Catálogo de eventos**
- Home com hero + grades de eventos, página de cada evento, admin
  criar/editar evento com lotes dinâmicos

**Fase 3 — Pagamento e ingressos**
- Checkout completo: escolher lote/quantidade → dados individuais de cada
  titular → redirecionamento real para o Mercado Pago (Checkout Pro)
- Webhook do Mercado Pago com **verificação real de assinatura**
  (HMAC-SHA256 conforme a documentação oficial) — sem isso, qualquer um
  poderia forjar uma notificação de "pagamento aprovado"
- Emissão de ingressos só acontece depois da confirmação do pagamento pelo
  webhook (nunca antes) — evita vender ingresso sem pagamento confirmado
- Verificação de estoque em transação no momento da confirmação (evita
  overselling); se o lote esgotar entre a criação do pedido e a
  confirmação do pagamento (caso raro), o pedido é marcado para estorno
  manual — estorno automático via API fica para uma fase futura
- Cada ingresso tem código único e QR Code gerado no servidor, com
  assinatura determinística (HMAC) — dá para revalidar o conteúdo do QR
  sem guardar nada extra no banco
- "Meus ingressos" e "Meus pedidos" reais no dashboard, com sidebar
  (Início, Meus ingressos, Meus pedidos, Minha conta)
- Página de status do pedido (`/pedido/[id]`) — para onde o Mercado Pago
  redireciona de volta

O que **ainda não existe** (vem na próxima fase): o restante do painel
administrativo — visualizar vendas, filtrar por evento, registrar venda
manual (fora do site), consultar/validar ingressos por código ou QR na
portaria, e o dashboard de faturamento.

### Testando o checkout localmente

O Mercado Pago precisa alcançar sua máquina para enviar o webhook de
confirmação — `localhost` sozinho não funciona. Para testar em
desenvolvimento, use um túnel (ex: `ngrok http 3000`) e configure
`NEXT_PUBLIC_APP_URL` com a URL pública gerada, além de usar suas
credenciais de **teste** do Mercado Pago (`MERCADO_PAGO_ACCESS_TOKEN` de
teste) e os [cartões de teste](https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/additional-content/your-integrations/test/cards)
deles para simular o pagamento.

## Stack

- **Frontend + Backend**: Next.js 14 (App Router) + TypeScript
- **Banco de dados**: PostgreSQL via Prisma ORM
- **Autenticação**: JWT (`jose`) em cookie `httpOnly`, senhas com `bcryptjs`
- **Pagamento**: Mercado Pago (Checkout Pro + webhook)
- **QR Code**: `qrcode`, com token assinado (HMAC) por ingresso
- **Validação**: Zod (inclui validação real de CPF, com dígitos verificadores)
- **Estilo**: Tailwind CSS
- **Ícones**: lucide-react

## Rodando localmente

### 1. Pré-requisitos

- Node.js 20+
- Uma URL de banco Postgres. O jeito mais simples e gratuito para começar é
  criar um banco na [Neon](https://neon.tech) (leva 2 minutos, não precisa
  cartão de crédito).

### 2. Instalar dependências

```bash
npm install
```

### 3. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite o `.env` e preencha pelo menos:

- `DATABASE_URL` e `DIRECT_URL` — a connection string do seu banco (a Neon
  te dá as duas; se seu provedor só tiver uma, use o mesmo valor nas duas)
- `JWT_SECRET` e `QR_SECRET` — gere um valor forte para cada um com
  `openssl rand -base64 48` (não reutilize o mesmo valor nos dois)

O `RESEND_API_KEY` pode ficar em branco por agora — sem ele, os e-mails de
recuperação de senha são apenas impressos no console do servidor, o que já
é suficiente para testar o fluxo em desenvolvimento. Já
`MERCADO_PAGO_ACCESS_TOKEN` e `MERCADO_PAGO_WEBHOOK_SECRET` **são
necessários para testar o checkout** (Fase 3) — use suas credenciais de
teste, disponíveis no painel de desenvolvedores do Mercado Pago.

### 4. Criar as tabelas no banco

```bash
npx prisma migrate dev --name init
```

Isso cria todas as tabelas (inclusive as de eventos/ingressos, que ainda não
têm API — elas só passam a ser usadas nas próximas fases).

### 5. (Opcional) Criar um usuário admin de teste

```bash
npm run db:seed
```

Isso cria `admin@onora.com.br` / `TrocarSenha123` (ou os valores de
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD`, se você definir essas variáveis).
Troque a senha assim que possível — este comando é só para desenvolvimento.

### 6. Rodar

```bash
npm run dev
```

Abra `http://localhost:3000` — a home já mostra os eventos de exemplo do
seed. Crie uma conta em `/criar-conta`, faça login em `/entrar`, e veja o
`/dashboard` protegido funcionando com o banco real. Para editar eventos,
entre com o usuário admin (`admin@onora.com.br` / `TrocarSenha123`, se você
rodou o seed) e acesse `/admin/eventos`.

### Checagem de tipos

```bash
npm run typecheck
```

## Deploy (Vercel + Neon) — sugestão mais simples

1. Suba este código para um repositório no GitHub.
2. Crie um banco na [Neon](https://neon.tech), copie as connection strings
   (pooled → `DATABASE_URL`, direct → `DIRECT_URL`).
3. Importe o repositório na [Vercel](https://vercel.com/new).
4. Em "Environment Variables", adicione `DATABASE_URL`, `DIRECT_URL` e
   `JWT_SECRET` (e depois `RESEND_API_KEY`/Mercado Pago, quando chegar a
   hora).
5. Rode as migrações contra o banco de produção uma vez, a partir da sua
   máquina, apontando o `.env` local para a `DATABASE_URL` de produção:
   ```bash
   npx prisma migrate deploy
   ```
6. Deploy. Pronto — `/entrar`, `/criar-conta`, `/dashboard` já funcionam de
   verdade em produção.

## Estrutura do projeto

```
prisma/
  schema.prisma      # modelo completo do banco (users, events, batches, orders, tickets)
  seed.ts             # cria um admin de teste + eventos de exemplo
src/
  app/
    api/
      auth/           # rotas de autenticação (signup, login, logout, me, forgot/reset password)
      admin/events/    # CRUD de eventos (admin) — GET/POST e GET/PATCH/DELETE por id
      checkout/         # cria pedido + preferência de pagamento no Mercado Pago
      webhooks/mercado-pago/  # confirma pagamento e emite os ingressos
    (auth)/           # páginas de entrar / criar conta / recuperar / redefinir senha (sem header/footer)
    (site)/           # páginas públicas: home, /eventos/[slug], /eventos/[slug]/comprar, /pedido/[id]
    admin/            # painel admin (layout protegido + eventos: listar/criar/editar)
    dashboard/        # área do usuário: início, ingressos, pedidos, conta (com sidebar)
    layout.tsx
  components/
    ui/               # componentes visuais genéricos (Field, botões, wordmark, etc.)
    layout/            # Header (server+client) e Footer do site público
    events/             # EventVisual (banner), EventCard, Hero — compartilhados entre home/evento/admin
    admin/               # EventForm (criar/editar evento)
    checkout/              # CheckoutFlow (seleção de lote, titulares, pagamento)
    tickets/                # TicketWalletCard (carteira digital de ingressos)
  lib/
    prisma.ts          # cliente Prisma singleton
    auth.ts             # emissão/verificação de JWT + cookies
    session.ts           # helpers de sessão para Server Components (requireAuth, requireAdmin)
    api-auth.ts            # helper de autorização para API routes (retorna JSON 401/403)
    password.ts              # hash de senha e tokens de recuperação
    validation.ts              # schemas Zod (CPF, eventos, lotes, checkout)
    slug.ts                     # geração de slug único para eventos
    format.ts                    # formatação de data/dinheiro em pt-BR
    email.ts                      # abstração de envio de e-mail
    safe-user.ts                   # remove o hash de senha antes de responder à API
    ticket.ts                       # código do pedido/ingresso + assinatura do QR
    qrcode.ts                        # geração da imagem do QR Code
    mercado-pago.ts                   # criação de preferência + verificação do webhook
  middleware.ts                       # protege /dashboard e /admin
```

## Notas de segurança para revisar antes do lançamento

- **Rate limiting**: os endpoints de login/signup/forgot-password/checkout
  ainda não têm limite de tentativas. Antes de lançar, adicione um rate
  limiter (ex: [Upstash Ratelimit](https://github.com/upstash/ratelimit),
  que funciona bem com Vercel/Edge) para evitar força bruta.
- **E-mail transacional**: configure um provedor de verdade (`RESEND_API_KEY`
  ou outro) antes do lançamento — sem isso, a recuperação de senha não
  chega ao usuário.
- **JWT_SECRET e QR_SECRET**: use valores gerados aleatoriamente (nunca os
  placeholders do `.env.example`), diferentes um do outro, e nunca os
  exponha publicamente.
- **MERCADO_PAGO_WEBHOOK_SECRET**: sem ele, o webhook rejeita todas as
  notificações (por segurança, o código nunca processa um pagamento sem
  conseguir verificar a assinatura). Configure-o no painel do Mercado Pago
  e aqui antes de testar o checkout.
- **Estorno em caso de esgotamento**: se um lote esgotar exatamente entre a
  criação do pedido e a confirmação do pagamento (janela pequena, mas
  possível), o pedido fica marcado como pago mas cancelado, e um log de
  erro é emitido — o estorno ao cliente, hoje, é manual. Automatizar isso
  via API do Mercado Pago é um bom próximo passo antes do lançamento.
- **CPF**: a validação confirma que o CPF é matematicamente válido, mas não
  confirma que pertence à pessoa que está se cadastrando (isso exigiria
  verificação com a Receita Federal ou um serviço terceirizado, fora do
  escopo desta fase).

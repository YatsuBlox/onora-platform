import { NextRequest, NextResponse } from "next/server";
import { AUTH_COOKIE_NAME, verifyAuthToken, type AuthPayload } from "@/lib/auth";
import { jsonError } from "@/lib/api-response";

type AuthResult = { payload: AuthPayload } | { errorResponse: NextResponse };

// Usado no início de API routes que só exigem estar logado (qualquer
// papel). Assim como `requireAdminFromRequest`, devolve uma resposta JSON
// de erro em vez de redirecionar — é isso que um cliente de API espera.
export async function requireUserFromRequest(request: NextRequest): Promise<AuthResult> {
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;
  if (!token) return { errorResponse: jsonError("Não autenticado", 401) };

  const payload = await verifyAuthToken(token);
  if (!payload) return { errorResponse: jsonError("Não autenticado", 401) };

  return { payload };
}

type AdminAuthResult = { payload: AuthPayload } | { errorResponse: NextResponse };

// Usado no início de API routes administrativas. Diferente de
// `requireAdmin()` (usado em Server Components, que redireciona), aqui
// devolvemos uma resposta JSON de erro — é isso que um cliente de API
// espera receber, não um redirecionamento de página.
export async function requireAdminFromRequest(request: NextRequest): Promise<AdminAuthResult> {
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;
  if (!token) {
    return { errorResponse: jsonError("Não autenticado", 401) };
  }

  const payload = await verifyAuthToken(token);
  if (!payload) {
    return { errorResponse: jsonError("Não autenticado", 401) };
  }

  if (payload.role !== "ADMIN") {
    return { errorResponse: jsonError("Acesso restrito a administradores", 403) };
  }

  return { payload };
}

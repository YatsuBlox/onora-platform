import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { AUTH_COOKIE_NAME, verifyAuthToken, type AuthPayload } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// Lê e valida o cookie de sessão da requisição atual. Retorna apenas o que
// está no próprio token (id, e-mail, papel) — não bate no banco.
export async function getAuthPayload(): Promise<AuthPayload | null> {
  const token = cookies().get(AUTH_COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyAuthToken(token);
}

// Igual ao anterior, mas busca o usuário completo no banco — use quando
// precisar de dados que não estão no token (nome, telefone, etc.), como em
// páginas de conta do usuário.
export async function getCurrentUser() {
  const payload = await getAuthPayload();
  if (!payload) return null;

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  return user;
}

// Para usar no topo de Server Components de páginas protegidas: redireciona
// para o login se não houver sessão válida, e devolve o payload caso haja.
export async function requireAuth(redirectTo = "/entrar"): Promise<AuthPayload> {
  const payload = await getAuthPayload();
  if (!payload) {
    redirect(redirectTo);
  }
  return payload;
}

export async function requireAdmin(): Promise<AuthPayload> {
  const payload = await requireAuth("/entrar");
  if (payload.role !== "ADMIN") {
    redirect("/dashboard");
  }
  return payload;
}

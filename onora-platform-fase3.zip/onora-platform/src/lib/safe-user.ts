import type { User } from "@prisma/client";

export type SafeUser = Omit<User, "passwordHash">;

// O objeto que vem do Prisma inclui o hash da senha — nunca deve sair da
// camada de API. Essa função garante que só os campos seguros sejam
// serializados na resposta JSON.
export function toSafeUser(user: User): SafeUser {
  const { passwordHash: _passwordHash, ...safeUser } = user;
  return safeUser;
}

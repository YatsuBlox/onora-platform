import { createHmac, timingSafeEqual } from "crypto";

const MP_API_BASE = "https://api.mercadopago.com";

function getAccessToken(): string {
  const token = process.env.MERCADO_PAGO_ACCESS_TOKEN;
  if (!token) {
    throw new Error(
      "MERCADO_PAGO_ACCESS_TOKEN não configurado — defina em .env antes de testar o checkout."
    );
  }
  return token;
}

type CreatePreferenceInput = {
  orderId: string;
  orderCode: string;
  eventName: string;
  batchName: string;
  unitPrice: number;
  quantity: number;
  payerEmail: string;
};

type MercadoPagoPreference = {
  id: string;
  init_point: string;
  sandbox_init_point: string;
};

// Cria uma "preference" no Mercado Pago (Checkout Pro) — o usuário é
// redirecionado para uma página hospedada pelo próprio Mercado Pago para
// pagar. `external_reference` é o nosso id de pedido: é assim que
// reconhecemos o pedido quando o webhook de confirmação chegar.
export async function createPaymentPreference(
  input: CreatePreferenceInput
): Promise<MercadoPagoPreference> {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  const response = await fetch(`${MP_API_BASE}/checkout/preferences`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getAccessToken()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      items: [
        {
          id: input.orderId,
          title: `${input.eventName} — ${input.batchName}`,
          quantity: input.quantity,
          unit_price: input.unitPrice,
          currency_id: "BRL",
        },
      ],
      payer: { email: input.payerEmail },
      external_reference: input.orderId,
      back_urls: {
        success: `${appUrl}/pedido/${input.orderId}`,
        pending: `${appUrl}/pedido/${input.orderId}`,
        failure: `${appUrl}/pedido/${input.orderId}`,
      },
      auto_return: "approved",
      notification_url: `${appUrl}/api/webhooks/mercado-pago`,
      statement_descriptor: "ONORA",
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Mercado Pago recusou a criação da preferência: ${response.status} ${body}`);
  }

  return response.json();
}

export type MercadoPagoPayment = {
  id: number;
  status: "approved" | "pending" | "in_process" | "rejected" | "cancelled" | "refunded" | string;
  external_reference: string | null;
};

export async function getPayment(paymentId: string): Promise<MercadoPagoPayment> {
  const response = await fetch(`${MP_API_BASE}/v1/payments/${paymentId}`, {
    headers: { Authorization: `Bearer ${getAccessToken()}` },
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Falha ao consultar pagamento no Mercado Pago: ${response.status} ${body}`);
  }
  return response.json();
}

// Verifica a assinatura do webhook conforme a documentação do Mercado Pago:
// o header `x-signature` vem como "ts=<timestamp>,v1=<hash>", e o hash é um
// HMAC-SHA256 de um "manifest" no formato
// "id:<data.id>;request-id:<x-request-id>;ts:<ts>;" usando o segredo do
// webhook (configurado no painel do Mercado Pago). Sem isso, qualquer um
// poderia forjar uma notificação de pagamento aprovado.
export function verifyMercadoPagoWebhookSignature(params: {
  xSignature: string | null;
  xRequestId: string | null;
  dataId: string;
}): boolean {
  const secret = process.env.MERCADO_PAGO_WEBHOOK_SECRET;
  if (!secret) {
    // Sem segredo configurado, não dá para verificar — o chamador decide
    // como tratar isso (em produção, isso deve ser tratado como erro fatal).
    return false;
  }
  if (!params.xSignature) return false;

  const parts = Object.fromEntries(
    params.xSignature.split(",").map((pair) => {
      const [key, value] = pair.split("=");
      return [key?.trim(), value?.trim()];
    })
  );
  const ts = parts.ts;
  const receivedHash = parts.v1;
  if (!ts || !receivedHash) return false;

  const manifest = `id:${params.dataId};request-id:${params.xRequestId ?? ""};ts:${ts};`;
  const expectedHash = createHmac("sha256", secret).update(manifest).digest("hex");

  // Comparação em tempo constante — evita vazar informação sobre o quanto
  // do hash está correto através do tempo de resposta.
  const a = Buffer.from(expectedHash);
  const b = Buffer.from(receivedHash);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

import { prisma } from "@/lib/prisma";

export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove acentos
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 80);
}

// Gera um slug único a partir do nome do evento, adicionando um sufixo
// numérico se já existir um evento com o mesmo slug base.
export async function generateUniqueEventSlug(name: string): Promise<string> {
  const base = slugify(name) || "evento";
  let candidate = base;
  let attempt = 1;

  while (await prisma.event.findUnique({ where: { slug: candidate } })) {
    attempt += 1;
    candidate = `${base}-${attempt}`;
  }

  return candidate;
}

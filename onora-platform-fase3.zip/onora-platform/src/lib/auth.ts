import { SignJWT, jwtVerify } from "jose";
import type { NextResponse } from "next/server";

// Usamos "jose" (em vez de "jsonwebtoken") porque também precisamos
// verificar o token dentro do middleware, que roda no Edge Runtime — o
// módulo "crypto" do Node não está disponível lá, mas "jose" funciona em
// ambos os ambientes.

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 16) {
  throw new Error(
    "JWT_SECRET não configurado (ou fraco demais). Defina uma string aleatória de pelo menos 32 caracteres em .env — veja .env.example."
  );
}
const secretKey = new TextEncoder().encode(JWT_SECRET);

export const AUTH_COOKIE_NAME = "onora_session";
const SESSION_DURATION = "7d";
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7; // 7 dias

export type AuthPayload = {
  sub: string; // id do usuário
  email: string;
  role: "USER" | "ADMIN";
};

export async function signAuthToken(payload: AuthPayload): Promise<string> {
  return new SignJWT({ email: payload.email, role: payload.role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime(SESSION_DURATION)
    .sign(secretKey);
}

export async function verifyAuthToken(token: string): Promise<AuthPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey);
    if (typeof payload.sub !== "string" || typeof payload.email !== "string") {
      return null;
    }
    const role = payload.role === "ADMIN" ? "ADMIN" : "USER";
    return { sub: payload.sub, email: payload.email, role };
  } catch {
    // Token expirado, assinatura inválida, ou malformado — tratamos tudo
    // como "não autenticado" em vez de vazar detalhes do erro.
    return null;
  }
}

// Usado dentro de Route Handlers, onde temos acesso a um NextResponse para
// anexar o cookie de sessão.
export function setAuthCookie(response: NextResponse, token: string): void {
  response.cookies.set(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
}

export function clearAuthCookie(response: NextResponse): void {
  response.cookies.set(AUTH_COOKIE_NAME, "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
}

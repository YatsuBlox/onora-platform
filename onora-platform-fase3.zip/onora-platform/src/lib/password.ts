import bcrypt from "bcryptjs";
import { randomBytes, createHash } from "crypto";

// Custo 12 é um bom equilíbrio entre segurança e tempo de resposta em 2026.
// Reavalie esse número periodicamente — o custo recomendado sobe com o
// tempo, conforme hardware fica mais rápido.
const BCRYPT_COST = 12;

export async function hashPassword(plainPassword: string): Promise<string> {
  return bcrypt.hash(plainPassword, BCRYPT_COST);
}

export async function verifyPassword(
  plainPassword: string,
  passwordHash: string
): Promise<boolean> {
  return bcrypt.compare(plainPassword, passwordHash);
}

// Gera um token aleatório para links de recuperação de senha. Retornamos o
// valor puro (para colocar na URL do e-mail) e o hash (para guardar no
// banco) — nunca armazenamos o token em texto plano.
export function generateResetToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString("hex");
  const tokenHash = createHash("sha256").update(token).digest("hex");
  return { token, tokenHash };
}

export function hashResetToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

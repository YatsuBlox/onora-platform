import { randomBytes } from "crypto";
import { SignJWT, jwtVerify } from "jose";

// Usado só para assinar o conteúdo do QR Code — propositalmente separado do
// JWT_SECRET de autenticação (segredos com finalidades diferentes não devem
// compartilhar a mesma chave). Se QR_SECRET não estiver definido, cai para
// o JWT_SECRET para não travar o ambiente de desenvolvimento — defina um
// QR_SECRET próprio antes do lançamento.
const secretSource = process.env.QR_SECRET || process.env.JWT_SECRET;
if (!secretSource || secretSource.length < 16) {
  throw new Error("QR_SECRET (ou JWT_SECRET) não configurado — veja .env.example.");
}
const qrSecretKey = new TextEncoder().encode(secretSource);

export function generateOrderCode(): string {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = randomBytes(2).toString("hex").toUpperCase();
  return `OND-${stamp}${rand}`;
}

export function generateTicketCode(): string {
  const group = () => randomBytes(2).toString("hex").toUpperCase();
  return `ONR-${group()}-${group()}`;
}

// Assinatura DETERMINÍSTICA (sem "iat"/"exp") — o mesmo ticketId sempre
// produz o mesmo token. Isso permite recalcular o conteúdo do QR Code a
// qualquer momento (ex: toda vez que o usuário abre "Meus ingressos") sem
// precisar guardar o token em lugar nenhum, e sem o QR mudar a cada vez.
export async function signTicketToken(ticketId: string): Promise<string> {
  return new SignJWT({}).setProtectedHeader({ alg: "HS256" }).setSubject(ticketId).sign(qrSecretKey);
}

// Usado futuramente pela validação de entrada (Fase 4 — checar ingresso na
// portaria). Confirma que o token não foi adulterado e devolve o id do
// ingresso assinado nele.
export async function verifyTicketToken(token: string): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, qrSecretKey);
    return typeof payload.sub === "string" ? payload.sub : null;
  } catch {
    return null;
  }
}

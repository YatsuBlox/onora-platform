// Abstração simples de envio de e-mail. Sem RESEND_API_KEY configurada, o
// e-mail é apenas registrado no console — assim o fluxo de "esqueci minha
// senha" funciona de ponta a ponta em desenvolvimento sem precisar de um
// provedor real. ANTES DO LANÇAMENTO, configure RESEND_API_KEY (ou troque
// pelo provedor de sua preferência) para que os e-mails saiam de verdade.

type SendEmailInput = {
  to: string;
  subject: string;
  html: string;
};

async function sendViaResend(input: SendEmailInput): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM ?? "ONORA <no-reply@onora.com.br>";

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: input.to,
      subject: input.subject,
      html: input.html,
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Falha ao enviar e-mail via Resend: ${response.status} ${body}`);
  }
}

export async function sendEmail(input: SendEmailInput): Promise<void> {
  if (process.env.RESEND_API_KEY) {
    await sendViaResend(input);
    return;
  }

  // Fallback de desenvolvimento — nenhum provedor configurado ainda.
  console.log("─────────────────────────────────────────");
  console.log("[email:dev] Nenhum provedor configurado — e-mail não enviado de verdade.");
  console.log(`Para: ${input.to}`);
  console.log(`Assunto: ${input.subject}`);
  console.log(input.html.replace(/<[^>]+>/g, " ").trim());
  console.log("─────────────────────────────────────────");
}

export function passwordResetEmailHtml(resetUrl: string): string {
  return `
    <div style="font-family: sans-serif; background:#000; color:#fff; padding:32px;">
      <h1 style="letter-spacing:0.1em;">ONORA</h1>
      <p>Recebemos um pedido para redefinir sua senha.</p>
      <p>
        <a href="${resetUrl}" style="display:inline-block; background:#fff; color:#000; padding:12px 24px; text-decoration:none; font-weight:600;">
          Redefinir senha
        </a>
      </p>
      <p style="color:#999; font-size:12px;">
        Se você não pediu isso, pode ignorar este e-mail com segurança.
        Este link expira em 1 hora.
      </p>
    </div>
  `;
}

import QRCode from "qrcode";

// Gera o QR Code como uma data URL (PNG embutido) pronta para usar num
// <img src="...">, sem precisar de armazenamento de arquivo nenhum.
export async function generateQrCodeDataUrl(content: string): Promise<string> {
  return QRCode.toDataURL(content, {
    margin: 1,
    width: 320,
    color: { dark: "#000000", light: "#FFFFFF" },
  });
}

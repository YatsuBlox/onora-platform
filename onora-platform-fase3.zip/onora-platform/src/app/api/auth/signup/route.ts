import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/password";
import { signAuthToken, setAuthCookie } from "@/lib/auth";
import { signupSchema } from "@/lib/validation";
import { jsonError, jsonZodError } from "@/lib/api-response";
import { toSafeUser } from "@/lib/safe-user";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = signupSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const { fullName, email, phone, cpf, password } = parsed.data;

  try {
    const passwordHash = await hashPassword(password);

    const user = await prisma.user.create({
      data: { fullName, email, phone, cpf, passwordHash },
    });

    const token = await signAuthToken({ sub: user.id, email: user.email, role: user.role });

    const response = NextResponse.json({ user: toSafeUser(user) }, { status: 201 });
    setAuthCookie(response, token);
    return response;
  } catch (err) {
    // Erro de unicidade do Postgres/Prisma (e-mail ou CPF já cadastrados).
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      const target = (err.meta?.target as string[] | undefined)?.[0];
      const field = target === "email" ? "e-mail" : target === "cpf" ? "CPF" : "dado";
      return jsonError(`Este ${field} já está cadastrado`, 409);
    }
    console.error("[signup] erro inesperado:", err);
    return jsonError("Não foi possível criar a conta. Tente novamente.", 500);
  }
}

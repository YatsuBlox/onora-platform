import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateResetToken } from "@/lib/password";
import { forgotPasswordSchema } from "@/lib/validation";
import { jsonError, jsonZodError } from "@/lib/api-response";
import { sendEmail, passwordResetEmailHtml } from "@/lib/email";

const RESET_TOKEN_TTL_MS = 60 * 60 * 1000; // 1 hora

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = forgotPasswordSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const { email } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });

  // Sempre respondemos com sucesso, exista ou não o e-mail — isso evita que
  // alguém use este endpoint para descobrir quais e-mails estão cadastrados.
  const genericResponse = () =>
    NextResponse.json({
      message: "Se este e-mail estiver cadastrado, você receberá um link de redefinição em instantes.",
    });

  if (!user) return genericResponse();

  const { token, tokenHash } = generateResetToken();

  await prisma.passwordResetToken.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MS),
    },
  });

  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const resetUrl = `${appUrl}/redefinir-senha?token=${token}`;

  await sendEmail({
    to: user.email,
    subject: "Redefinição de senha — ONORA",
    html: passwordResetEmailHtml(resetUrl),
  });

  return genericResponse();
}

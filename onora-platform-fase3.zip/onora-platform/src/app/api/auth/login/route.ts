import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/password";
import { signAuthToken, setAuthCookie } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { jsonError, jsonZodError } from "@/lib/api-response";
import { toSafeUser } from "@/lib/safe-user";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });

  // Mensagem genérica de propósito: não revelamos se o problema foi o
  // e-mail não cadastrado ou a senha errada, para não ajudar quem tenta
  // descobrir e-mails cadastrados por tentativa e erro.
  const invalidCredentialsResponse = () => jsonError("E-mail ou senha inválidos", 401);

  if (!user) return invalidCredentialsResponse();

  const passwordMatches = await verifyPassword(password, user.passwordHash);
  if (!passwordMatches) return invalidCredentialsResponse();

  const token = await signAuthToken({ sub: user.id, email: user.email, role: user.role });

  const response = NextResponse.json({ user: toSafeUser(user) }, { status: 200 });
  setAuthCookie(response, token);
  return response;
}

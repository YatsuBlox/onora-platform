import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuthToken, AUTH_COOKIE_NAME } from "@/lib/auth";
import { jsonError, jsonOk } from "@/lib/api-response";
import { toSafeUser } from "@/lib/safe-user";

export async function GET(request: NextRequest) {
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;
  if (!token) return jsonError("Não autenticado", 401);

  const payload = await verifyAuthToken(token);
  if (!payload) return jsonError("Não autenticado", 401);

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  if (!user) return jsonError("Não autenticado", 401);

  return jsonOk({ user: toSafeUser(user) });
}

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, hashResetToken } from "@/lib/password";
import { resetPasswordSchema } from "@/lib/validation";
import { jsonError, jsonZodError, jsonOk } from "@/lib/api-response";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = resetPasswordSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const { token, password } = parsed.data;
  const tokenHash = hashResetToken(token);

  const resetRecord = await prisma.passwordResetToken.findUnique({
    where: { tokenHash },
  });

  const invalidTokenResponse = () =>
    jsonError("Este link de redefinição é inválido ou já expirou. Peça um novo link.", 400);

  if (!resetRecord) return invalidTokenResponse();
  if (resetRecord.usedAt) return invalidTokenResponse();
  if (resetRecord.expiresAt.getTime() < Date.now()) return invalidTokenResponse();

  const passwordHash = await hashPassword(password);

  await prisma.$transaction([
    prisma.user.update({
      where: { id: resetRecord.userId },
      data: { passwordHash },
    }),
    prisma.passwordResetToken.update({
      where: { id: resetRecord.id },
      data: { usedAt: new Date() },
    }),
  ]);

  return jsonOk({ message: "Senha redefinida com sucesso. Você já pode entrar com a nova senha." });
}

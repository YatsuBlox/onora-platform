import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { checkoutSchema } from "@/lib/validation";
import { requireUserFromRequest } from "@/lib/api-auth";
import { jsonError, jsonZodError, jsonOk } from "@/lib/api-response";
import { generateOrderCode } from "@/lib/ticket";
import { createPaymentPreference } from "@/lib/mercado-pago";

export async function POST(request: NextRequest) {
  const auth = await requireUserFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const { eventId, batchId, holders } = parsed.data;
  const quantity = holders.length;

  const [user, event] = await Promise.all([
    prisma.user.findUnique({ where: { id: auth.payload.sub } }),
    prisma.event.findUnique({ where: { id: eventId }, include: { batches: true } }),
  ]);

  if (!user) return jsonError("Usuário não encontrado", 404);
  if (!event) return jsonError("Evento não encontrado", 404);
  if (event.status !== "ACTIVE") return jsonError("Este evento não está com vendas abertas", 409);

  const batch = event.batches.find((b) => b.id === batchId);
  if (!batch) return jsonError("Lote não encontrado", 404);

  const available = batch.totalQuantity - batch.soldQuantity;
  if (available < quantity) {
    return jsonError(`Restam apenas ${Math.max(available, 0)} ingresso(s) neste lote`, 409);
  }

  const unitPrice = Number(batch.price);
  const totalAmount = unitPrice * quantity;

  // Tenta algumas vezes no caso (muito raro) de colisão do código gerado.
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const order = await prisma.order.create({
        data: {
          code: generateOrderCode(),
          userId: user.id,
          eventId: event.id,
          totalAmount,
          channel: "ONLINE",
          paymentMethod: "MERCADO_PAGO",
          paymentStatus: "PENDING",
          status: "PENDING",
        },
      });

      // Os dados dos titulares ficam guardados no pedido (pendingHolders)
      // até o webhook confirmar o pagamento — é só nesse momento que os
      // Tickets de verdade são criados (ver /api/webhooks/mercado-pago).
      let preference;
      try {
        preference = await createPaymentPreference({
          orderId: order.id,
          orderCode: order.code,
          eventName: event.name,
          batchName: batch.name,
          unitPrice,
          quantity,
          payerEmail: user.email,
        });
      } catch (mpError) {
        // Se o Mercado Pago falhar, não deixamos um pedido órfão para trás.
        await prisma.order.delete({ where: { id: order.id } });
        throw mpError;
      }

      const updatedOrder = await prisma.order.update({
        where: { id: order.id },
        data: {
          mercadoPagoPreferenceId: preference.id,
          pendingBatchId: batch.id,
          pendingHolders: holders,
        },
      });

      return jsonOk({
        order: { id: updatedOrder.id, code: updatedOrder.code },
        redirectUrl: preference.init_point,
      });
    } catch (err) {
      const isCodeCollision =
        err instanceof Prisma.PrismaClientKnownRequestError &&
        err.code === "P2002" &&
        (err.meta?.target as string[] | undefined)?.includes("code");
      if (isCodeCollision && attempt < 2) continue;

      console.error("[checkout] erro inesperado:", err);
      return jsonError("Não foi possível iniciar o pagamento. Tente novamente.", 500);
    }
  }

  return jsonError("Não foi possível iniciar o pagamento. Tente novamente.", 500);
}

import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getPayment, verifyMercadoPagoWebhookSignature } from "@/lib/mercado-pago";
import { generateTicketCode } from "@/lib/ticket";

type TicketHolderPayload = { name: string; phone: string; email?: string };

// Mercado Pago exige uma resposta 2xx rápida, ou ele reenvia a notificação
// depois. Por isso, mesmo em casos que tratamos como "nada a fazer" (ex:
// pedido já processado), respondemos 200 em vez de erro.
export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  const dataId = body?.data?.id ? String(body.data.id) : request.nextUrl.searchParams.get("data.id");
  const type = body?.type ?? request.nextUrl.searchParams.get("type");

  if (type !== "payment" || !dataId) {
    // Outros tipos de notificação (ex: merchant_order) — confirmamos o
    // recebimento e ignoramos.
    return NextResponse.json({ ok: true });
  }

  const signatureValid = verifyMercadoPagoWebhookSignature({
    xSignature: request.headers.get("x-signature"),
    xRequestId: request.headers.get("x-request-id"),
    dataId,
  });
  if (!signatureValid) {
    console.error("[webhook mercado-pago] assinatura inválida — notificação ignorada");
    return NextResponse.json({ error: "Assinatura inválida" }, { status: 401 });
  }

  let payment;
  try {
    payment = await getPayment(dataId);
  } catch (err) {
    console.error("[webhook mercado-pago] falha ao consultar pagamento:", err);
    // 500 faz o Mercado Pago tentar de novo mais tarde.
    return NextResponse.json({ error: "Falha ao consultar pagamento" }, { status: 500 });
  }

  const orderId = payment.external_reference;
  if (!orderId) return NextResponse.json({ ok: true });

  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) {
    console.error(`[webhook mercado-pago] pedido ${orderId} não encontrado`);
    return NextResponse.json({ ok: true });
  }

  // Idempotência: se já processamos esse pedido, não repetimos o trabalho
  // (o Mercado Pago pode reenviar a mesma notificação mais de uma vez).
  if (order.status === "COMPLETED" || order.status === "CANCELED") {
    return NextResponse.json({ ok: true });
  }

  if (payment.status === "approved") {
    try {
      await confirmOrder(order.id, String(payment.id));
    } catch (err) {
      console.error("[webhook mercado-pago] falha ao confirmar pedido:", err);
      return NextResponse.json({ error: "Falha ao confirmar pedido" }, { status: 500 });
    }
  } else if (payment.status === "rejected" || payment.status === "cancelled") {
    await prisma.order.update({
      where: { id: order.id },
      data: {
        paymentStatus: "REJECTED",
        status: "CANCELED",
        pendingBatchId: null,
        pendingHolders: Prisma.JsonNull,
      },
    });
  } else {
    // pending / in_process / etc — ainda não é definitivo.
    await prisma.order.update({ where: { id: order.id }, data: { paymentStatus: "PENDING" } });
  }

  return NextResponse.json({ ok: true });
}

async function confirmOrder(orderId: string, mercadoPagoPaymentId: string) {
  await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUniqueOrThrow({
      where: { id: orderId },
      include: { event: { include: { batches: true } } },
    });

    const holders = (order.pendingHolders as unknown as TicketHolderPayload[] | null) ?? [];
    const batch = order.event.batches.find((b) => b.id === order.pendingBatchId);

    if (!batch) {
      throw new Error(`Lote não encontrado para o pedido ${orderId}`);
    }

    const quantity = holders.length;
    const available = batch.totalQuantity - batch.soldQuantity;

    if (available < quantity) {
      // Caso raro: esgotou entre a criação do pedido e a confirmação do
      // pagamento. O pagamento foi aprovado mas não há como emitir os
      // ingressos — marcamos o pedido para acompanhamento manual (estorno).
      // Uma automação de estorno via API fica para uma fase futura.
      await tx.order.update({
        where: { id: orderId },
        data: {
          paymentStatus: "APPROVED",
          status: "CANCELED",
          mercadoPagoPaymentId,
        },
      });
      console.error(
        `[webhook mercado-pago] ATENÇÃO: pedido ${orderId} pago mas sem estoque — estorno manual necessário`
      );
      return;
    }

    await tx.batch.update({
      where: { id: batch.id },
      data: { soldQuantity: { increment: quantity } },
    });

    for (const holder of holders) {
      await tx.ticket.create({
        data: {
          code: generateTicketCode(),
          orderId,
          eventId: order.eventId,
          batchId: batch.id,
          holderName: holder.name,
          holderPhone: holder.phone,
          holderEmail: holder.email || null,
        },
      });
    }

    await tx.order.update({
      where: { id: orderId },
      data: {
        paymentStatus: "APPROVED",
        status: "COMPLETED",
        mercadoPagoPaymentId,
        pendingBatchId: null,
        pendingHolders: Prisma.JsonNull,
      },
    });
  });
}

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { eventInputSchema } from "@/lib/validation";
import { generateUniqueEventSlug } from "@/lib/slug";
import { requireAdminFromRequest } from "@/lib/api-auth";
import { jsonError, jsonZodError, jsonOk } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  const auth = await requireAdminFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  const events = await prisma.event.findMany({
    orderBy: { date: "desc" },
    include: { batches: true },
  });

  return jsonOk({ events });
}

export async function POST(request: NextRequest) {
  const auth = await requireAdminFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = eventInputSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const data = parsed.data;
  const date = new Date(data.date);
  if (Number.isNaN(date.getTime())) return jsonError("Data/horário inválidos");

  const slug = await generateUniqueEventSlug(data.name);

  const event = await prisma.event.create({
    data: {
      name: data.name,
      slug,
      tagline: data.tagline || null,
      description: data.description || null,
      bannerUrl: data.bannerUrl || null,
      date,
      venue: data.venue,
      address: data.address || null,
      attractions: data.attractions,
      info: data.info || null,
      status: data.status,
      isHero: data.isHero,
      batches: {
        create: data.batches.map((batch) => ({
          name: batch.name,
          price: batch.price,
          totalQuantity: batch.totalQuantity,
        })),
      },
    },
    include: { batches: true },
  });

  return jsonOk({ event }, 201);
}

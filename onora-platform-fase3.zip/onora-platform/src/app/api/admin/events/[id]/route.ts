import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { eventInputSchema } from "@/lib/validation";
import { requireAdminFromRequest } from "@/lib/api-auth";
import { jsonError, jsonZodError, jsonOk } from "@/lib/api-response";

type RouteParams = { params: { id: string } };

export async function GET(request: NextRequest, { params }: RouteParams) {
  const auth = await requireAdminFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  const event = await prisma.event.findUnique({
    where: { id: params.id },
    include: { batches: true },
  });
  if (!event) return jsonError("Evento não encontrado", 404);

  return jsonOk({ event });
}

export async function PATCH(request: NextRequest, { params }: RouteParams) {
  const auth = await requireAdminFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  const body = await request.json().catch(() => null);
  if (!body) return jsonError("Corpo da requisição inválido");

  const parsed = eventInputSchema.safeParse(body);
  if (!parsed.success) return jsonZodError(parsed.error);

  const data = parsed.data;
  const date = new Date(data.date);
  if (Number.isNaN(date.getTime())) return jsonError("Data/horário inválidos");

  const existing = await prisma.event.findUnique({
    where: { id: params.id },
    include: { batches: true },
  });
  if (!existing) return jsonError("Evento não encontrado", 404);

  // Reconcilia os lotes enviados com os que já existem no banco:
  // - lote com id existente → atualiza
  // - lote sem id → cria
  // - lote que existia mas não veio na lista → remove, EXCETO se já teve
  //   venda (soldQuantity > 0), caso em que bloqueamos a edição inteira em
  //   vez de apagar silenciosamente um lote com ingressos vendidos.
  const incomingIds = new Set(data.batches.map((b) => b.id).filter(Boolean));
  const removedBatchWithSales = existing.batches.find(
    (b) => !incomingIds.has(b.id) && b.soldQuantity > 0
  );
  if (removedBatchWithSales) {
    return jsonError(
      `O lote "${removedBatchWithSales.name}" já tem ingressos vendidos e não pode ser removido.`,
      409
    );
  }

  // Também não deixamos reduzir a quantidade total abaixo do que já foi
  // vendido naquele lote.
  for (const batch of data.batches) {
    if (!batch.id) continue;
    const current = existing.batches.find((b) => b.id === batch.id);
    if (current && batch.totalQuantity < current.soldQuantity) {
      return jsonError(
        `O lote "${batch.name}" já vendeu ${current.soldQuantity} ingresso(s) — a quantidade não pode ser menor que isso.`,
        409
      );
    }
  }

  const batchesToDelete = existing.batches.filter((b) => !incomingIds.has(b.id));

  try {
    const event = await prisma.$transaction(async (tx) => {
      if (batchesToDelete.length > 0) {
        await tx.batch.deleteMany({
          where: { id: { in: batchesToDelete.map((b) => b.id) } },
        });
      }

      for (const batch of data.batches) {
        if (batch.id) {
          await tx.batch.update({
            where: { id: batch.id },
            data: { name: batch.name, price: batch.price, totalQuantity: batch.totalQuantity },
          });
        } else {
          await tx.batch.create({
            data: {
              eventId: params.id,
              name: batch.name,
              price: batch.price,
              totalQuantity: batch.totalQuantity,
            },
          });
        }
      }

      return tx.event.update({
        where: { id: params.id },
        data: {
          name: data.name,
          tagline: data.tagline || null,
          description: data.description || null,
          bannerUrl: data.bannerUrl || null,
          date,
          venue: data.venue,
          address: data.address || null,
          attractions: data.attractions,
          info: data.info || null,
          status: data.status,
          isHero: data.isHero,
        },
        include: { batches: true },
      });
    });

    return jsonOk({ event });
  } catch (err) {
    console.error("[admin/events PATCH] erro inesperado:", err);
    return jsonError("Não foi possível salvar o evento. Tente novamente.", 500);
  }
}

export async function DELETE(request: NextRequest, { params }: RouteParams) {
  const auth = await requireAdminFromRequest(request);
  if ("errorResponse" in auth) return auth.errorResponse;

  try {
    await prisma.event.delete({ where: { id: params.id } });
    return jsonOk({ ok: true });
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError) {
      if (err.code === "P2025") return jsonError("Evento não encontrado", 404);
      if (err.code === "P2003") {
        return jsonError(
          "Não é possível excluir: este evento já tem pedidos ou ingressos vinculados. Altere o status para \"Cancelado\" em vez de excluir.",
          409
        );
      }
    }
    console.error("[admin/events DELETE] erro inesperado:", err);
    return jsonError("Não foi possível excluir o evento.", 500);
  }
}

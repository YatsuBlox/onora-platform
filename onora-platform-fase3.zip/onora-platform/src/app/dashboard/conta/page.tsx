import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function MyAccountPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const fields: [string, string][] = [
    ["Nome completo", user.fullName],
    ["E-mail", user.email],
    ["Telefone", user.phone],
    ["CPF", user.cpf],
  ];

  return (
    <div className="max-w-md">
      <h1 className="font-display text-3xl text-white mb-10">Minha conta</h1>
      <div className="border border-white/10 p-6 space-y-4 text-sm">
        {fields.map(([label, value]) => (
          <div key={label} className="flex justify-between border-b border-white/10 pb-3 last:border-0 last:pb-0">
            <span className="text-white/40 uppercase tracking-wide text-[11px] pt-0.5">{label}</span>
            <span className="text-white">{value}</span>
          </div>
        ))}
      </div>
      <p className="text-white/25 text-xs mt-6">
        Edição de perfil e troca de senha chegam em uma fase futura.
      </p>
    </div>
  );
}

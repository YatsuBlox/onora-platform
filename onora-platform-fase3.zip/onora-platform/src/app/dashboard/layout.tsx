import type { ReactNode } from "react";
import Link from "next/link";
import { LayoutDashboard, Ticket, Receipt, User } from "lucide-react";
import { requireAuth } from "@/lib/session";
import { Wordmark } from "@/components/ui/wordmark";
import { LogoutButton } from "@/components/ui/logout-button";

const navItems = [
  { href: "/dashboard", label: "Início", icon: LayoutDashboard },
  { href: "/dashboard/ingressos", label: "Meus ingressos", icon: Ticket },
  { href: "/dashboard/pedidos", label: "Meus pedidos", icon: Receipt },
  { href: "/dashboard/conta", label: "Minha conta", icon: User },
];

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const payload = await requireAuth();

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-10 md:py-16 grid md:grid-cols-[200px_1fr] gap-8 md:gap-16">
        <div>
          <div className="flex items-center justify-between mb-10 md:block">
            <Link href="/">
              <Wordmark size="text-lg" />
            </Link>
            <div className="md:hidden">
              <LogoutButton />
            </div>
          </div>
          <nav className="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible -mx-5 px-5 md:mx-0 md:px-0 pb-2 md:pb-0 md:mt-10">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="whitespace-nowrap flex items-center gap-3 py-2.5 text-[13px] uppercase tracking-wide text-white/50 hover:text-white transition-colors"
              >
                <item.icon className="w-4 h-4 hidden md:block" /> {item.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:block mt-10">
            <LogoutButton />
          </div>
          {payload.role === "ADMIN" && (
            <Link
              href="/admin/eventos"
              className="hidden md:block mt-3 text-[13px] uppercase tracking-wide text-white/30 hover:text-white transition-colors"
            >
              Painel admin
            </Link>
          )}
        </div>

        <div>{children}</div>
      </div>
    </div>
  );
}

import Link from "next/link";
import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { TicketWalletCard } from "@/components/tickets/ticket-wallet-card";
import { signTicketToken } from "@/lib/ticket";
import { generateQrCodeDataUrl } from "@/lib/qrcode";

export const dynamic = "force-dynamic";

export default async function DashboardHomePage() {
  const user = await getCurrentUser();
  if (!user) return null; // o layout já garante sessão válida antes de chegar aqui

  const [ticketCount, orderCount, nextTicket] = await Promise.all([
    prisma.ticket.count({ where: { order: { userId: user.id }, status: "VALID" } }),
    prisma.order.count({ where: { userId: user.id } }),
    prisma.ticket.findFirst({
      where: { order: { userId: user.id }, status: "VALID" },
      orderBy: { event: { date: "asc" } },
      include: { event: true, batch: true },
    }),
  ]);

  const nextTicketQr = nextTicket
    ? await generateQrCodeDataUrl(await signTicketToken(nextTicket.id))
    : null;

  return (
    <div>
      <h1 className="font-display text-4xl text-white mb-10">Olá, {user.fullName.split(" ")[0]}</h1>

      <div className="grid grid-cols-2 gap-6 mb-14">
        <div className="border-l-2 border-white/15 pl-4 py-1">
          <div className="text-[11px] uppercase tracking-[0.12em] text-white/35 mb-1.5">Ingressos ativos</div>
          <div className="text-2xl font-display text-white">{ticketCount}</div>
        </div>
        <div className="border-l-2 border-white/15 pl-4 py-1">
          <div className="text-[11px] uppercase tracking-[0.12em] text-white/35 mb-1.5">Pedidos</div>
          <div className="text-2xl font-display text-white">{orderCount}</div>
        </div>
      </div>

      {nextTicket ? (
        <div>
          <div className="text-[11px] uppercase tracking-[0.15em] text-white/40 mb-4">Próximo ingresso</div>
          <TicketWalletCard
            ticket={{
              id: nextTicket.id,
              code: nextTicket.code,
              status: nextTicket.status,
              holderName: nextTicket.holderName,
              eventName: nextTicket.event.name,
              venue: nextTicket.event.venue,
              date: nextTicket.event.date,
              batchName: nextTicket.batch.name,
            }}
            qrDataUrl={nextTicketQr ?? undefined}
          />
        </div>
      ) : (
        <p className="text-white/30 text-sm">
          Você ainda não tem ingressos.{" "}
          <Link href="/" className="text-white hover:underline">
            Ver eventos
          </Link>
        </p>
      )}
    </div>
  );
}

import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { formatMoney, formatDateFull } from "@/lib/format";

export const dynamic = "force-dynamic";

const paymentStatusLabel: Record<string, string> = {
  PENDING: "pendente",
  APPROVED: "aprovado",
  REJECTED: "recusado",
  REFUNDED: "estornado",
};

const orderStatusLabel: Record<string, string> = {
  PENDING: "pendente",
  COMPLETED: "concluído",
  CANCELED: "cancelado",
};

export default async function MyOrdersPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const orders = await prisma.order.findMany({
    where: { userId: user.id },
    include: { event: true, tickets: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <h1 className="font-display text-3xl text-white mb-10">Meus pedidos</h1>

      {orders.length === 0 && <p className="text-white/30 text-sm">Você ainda não tem pedidos.</p>}

      <div className="space-y-0">
        {orders.map((order) => (
          <div key={order.id} className="flex flex-wrap items-center justify-between gap-2 py-5 border-b border-white/10">
            <div>
              <div className="text-white text-[15px]">{order.event.name}</div>
              <div className="text-xs text-white/35">
                {order.code} · {formatDateFull(order.createdAt)}
              </div>
            </div>
            <div className="flex items-center gap-6 text-sm">
              <span className="text-white/50">{order.tickets.length || "—"} ingresso(s)</span>
              <span className="text-white tabular-nums">{formatMoney(Number(order.totalAmount))}</span>
              <span className="text-[11px] uppercase tracking-wide text-white/60">
                {paymentStatusLabel[order.paymentStatus]}
              </span>
              <span className="text-[11px] uppercase tracking-wide text-white/40">
                {orderStatusLabel[order.status]}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

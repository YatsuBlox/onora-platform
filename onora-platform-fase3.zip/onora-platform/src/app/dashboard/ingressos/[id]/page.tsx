import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getAuthPayload } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { signTicketToken } from "@/lib/ticket";
import { generateQrCodeDataUrl } from "@/lib/qrcode";
import { formatDateFull, formatTime } from "@/lib/format";

export const dynamic = "force-dynamic";

type TicketDetailPageProps = { params: { id: string } };

const statusLabel: Record<string, string> = {
  VALID: "válido",
  USED: "utilizado",
  CANCELED: "cancelado",
};

export default async function TicketDetailPage({ params }: TicketDetailPageProps) {
  const auth = await getAuthPayload();
  if (!auth) notFound();

  const ticket = await prisma.ticket.findUnique({
    where: { id: params.id },
    include: { event: true, batch: true, order: true },
  });

  if (!ticket) notFound();
  if (ticket.order.userId !== auth.sub && auth.role !== "ADMIN") notFound();

  const qrDataUrl = await generateQrCodeDataUrl(await signTicketToken(ticket.id));
  const valid = ticket.status === "VALID";

  return (
    <div className="max-w-md mx-auto px-6 py-10">
      <Link
        href="/dashboard/ingressos"
        className="flex items-center gap-1.5 text-[13px] uppercase tracking-wide text-white/40 hover:text-white mb-10 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Meus ingressos
      </Link>

      <div className="border border-white/15">
        <div className="p-8 text-center border-b border-dashed border-white/15">
          <span className="text-[11px] uppercase tracking-[0.12em] text-white/60">
            {statusLabel[ticket.status]}
          </span>
          <h1 className="font-display text-3xl text-white mt-4">{ticket.event.name}</h1>
          <p className="text-sm text-white/40 mt-1">
            {formatDateFull(ticket.event.date)} · {formatTime(ticket.event.date)}
          </p>
        </div>

        <div className="p-8 flex justify-center">
          {/* eslint-disable-next-line @next/next/no-img-element -- data URL gerada no servidor */}
          <img src={qrDataUrl} alt="" className={`w-56 h-56 ${valid ? "" : "opacity-40 grayscale"}`} />
        </div>

        <div className="px-8 pb-8">
          <div className="text-center text-sm tracking-[0.2em] text-white/50 mb-8">{ticket.code}</div>
          <div className="space-y-4">
            {[
              ["Titular", ticket.holderName],
              ["Local", ticket.event.venue],
              ["Tipo", ticket.batch.name],
              ["Status", statusLabel[ticket.status]],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm border-b border-white/10 pb-3">
                <span className="text-white/35 uppercase tracking-wide text-[11px] pt-0.5">{k}</span>
                <span className="text-white text-right">{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

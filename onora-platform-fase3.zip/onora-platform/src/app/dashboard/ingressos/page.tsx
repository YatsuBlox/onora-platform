import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { TicketWalletCard } from "@/components/tickets/ticket-wallet-card";
import { signTicketToken } from "@/lib/ticket";
import { generateQrCodeDataUrl } from "@/lib/qrcode";

export const dynamic = "force-dynamic";

export default async function MyTicketsPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const tickets = await prisma.ticket.findMany({
    where: { order: { userId: user.id } },
    include: { event: true, batch: true },
    orderBy: { event: { date: "asc" } },
  });

  const ticketsWithQr = await Promise.all(
    tickets.map(async (t) => ({
      ticket: t,
      qrDataUrl: await generateQrCodeDataUrl(await signTicketToken(t.id)),
    }))
  );

  return (
    <div>
      <h1 className="font-display text-3xl text-white mb-10">Meus ingressos</h1>

      {tickets.length === 0 && <p className="text-white/30 text-sm">Você ainda não tem ingressos.</p>}

      <div className="space-y-4">
        {ticketsWithQr.map(({ ticket, qrDataUrl }) => (
          <TicketWalletCard
            key={ticket.id}
            ticket={{
              id: ticket.id,
              code: ticket.code,
              status: ticket.status,
              holderName: ticket.holderName,
              eventName: ticket.event.name,
              venue: ticket.event.venue,
              date: ticket.event.date,
              batchName: ticket.batch.name,
            }}
            qrDataUrl={qrDataUrl}
          />
        ))}
      </div>
    </div>
  );
}

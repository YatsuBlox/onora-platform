import { prisma } from "@/lib/prisma";
import { Hero } from "@/components/events/hero";
import { EventCard } from "@/components/events/event-card";

export const dynamic = "force-dynamic"; // sempre busca eventos atualizados, sem cache estático

export default async function HomePage() {
  const [activeEvents, pastEvents] = await Promise.all([
    prisma.event.findMany({ where: { status: "ACTIVE" }, orderBy: { date: "asc" } }),
    prisma.event.findMany({ where: { status: "FINISHED" }, orderBy: { date: "desc" }, take: 6 }),
  ]);

  const heroEvent = activeEvents.find((e) => e.isHero) ?? activeEvents[0] ?? null;
  const upcomingEvents = activeEvents.filter((e) => e.id !== heroEvent?.id);

  return (
    <main>
      {heroEvent ? (
        <Hero event={heroEvent} />
      ) : (
        <div className="h-[50vh] flex items-center justify-center text-white/30 text-sm uppercase tracking-widest px-6 text-center">
          Nenhum evento ativo no momento
        </div>
      )}

      <section className="max-w-7xl mx-auto px-5 md:px-8 pt-20 md:pt-28">
        <div className="flex items-end justify-between mb-8 md:mb-10">
          <div>
            <div className="text-[11px] uppercase tracking-[0.25em] text-white/40 mb-2">
              Agenda ONORA
            </div>
            <h2 className="font-display text-3xl md:text-4xl text-white">Próximos eventos</h2>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-5 md:gap-8">
          {activeEvents.length === 0 && (
            <p className="text-white/30 text-sm col-span-full">Nenhum evento ativo cadastrado.</p>
          )}
          {heroEvent && <EventCard event={heroEvent} />}
          {upcomingEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-5 md:px-8 pt-24 md:pt-32 pb-24">
        <div className="mb-8 md:mb-10">
          <div className="text-[11px] uppercase tracking-[0.25em] text-white/40 mb-2">Acervo</div>
          <h2 className="font-display text-3xl md:text-4xl text-white">Eventos anteriores</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-5 md:gap-8 opacity-60 grayscale">
          {pastEvents.length === 0 && (
            <p className="text-white/30 text-sm col-span-full">Nenhum evento anterior.</p>
          )}
          {pastEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </section>
    </main>
  );
}

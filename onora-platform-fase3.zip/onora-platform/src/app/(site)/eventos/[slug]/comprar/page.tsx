import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/session";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const dynamic = "force-dynamic";

type ComprarPageProps = { params: { slug: string } };

export default async function ComprarPage({ params }: ComprarPageProps) {
  // Sem sessão, manda para o login e traz o usuário de volta pra cá depois.
  await requireAuth(`/entrar?redirect=/eventos/${params.slug}/comprar`);

  const event = await prisma.event.findUnique({
    where: { slug: params.slug },
    include: { batches: { orderBy: { createdAt: "asc" } } },
  });

  if (!event || event.status !== "ACTIVE") notFound();

  const batches = event.batches.map((b) => ({
    id: b.id,
    name: b.name,
    price: Number(b.price),
    available: b.totalQuantity - b.soldQuantity,
  }));

  if (batches.every((b) => b.available <= 0)) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white/40 text-sm px-6 text-center">
        Este evento está esgotado.
      </div>
    );
  }

  return (
    <CheckoutFlow eventId={event.id} eventName={event.name} eventSlug={event.slug} batches={batches} />
  );
}

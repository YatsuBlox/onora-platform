import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2, Clock, XCircle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/session";
import { formatMoney } from "@/lib/format";
import { primaryButtonClass, ghostButtonClass } from "@/components/ui/buttons";

export const dynamic = "force-dynamic";

type OrderStatusPageProps = { params: { id: string } };

const statusContent = {
  APPROVED: {
    icon: CheckCircle2,
    title: "Pagamento confirmado",
    description: "Seus ingressos já estão disponíveis em \"Meus ingressos\".",
  },
  PENDING: {
    icon: Clock,
    title: "Pagamento em confirmação",
    description:
      "Assim que o Mercado Pago confirmar o pagamento (pode levar alguns instantes), seus ingressos aparecem automaticamente em \"Meus ingressos\". Você pode fechar esta página.",
  },
  REJECTED: {
    icon: XCircle,
    title: "Pagamento não aprovado",
    description: "Não foi possível confirmar o pagamento. Você pode tentar novamente.",
  },
  REFUNDED: {
    icon: XCircle,
    title: "Pagamento estornado",
    description: "Este pagamento foi estornado.",
  },
};

export default async function OrderStatusPage({ params }: OrderStatusPageProps) {
  const auth = await requireAuth(`/entrar?redirect=/pedido/${params.id}`);

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { event: true, tickets: true },
  });

  if (!order) notFound();
  // Um pedido só pode ser visto pelo próprio dono (ou por um admin).
  if (order.userId !== auth.sub && auth.role !== "ADMIN") notFound();

  const content = statusContent[order.paymentStatus];
  const Icon = content.icon;

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-24">
      <div className="w-full max-w-sm text-center space-y-6">
        <Icon className="w-10 h-10 text-white mx-auto" strokeWidth={1.3} />
        <h1 className="font-display text-2xl text-white">{content.title}</h1>
        <p className="text-sm text-white/50">{content.description}</p>

        <div className="border border-white/10 p-5 text-left text-sm space-y-2 mt-8">
          <div className="flex justify-between">
            <span className="text-white/40">Pedido</span>
            <span className="text-white">{order.code}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/40">Evento</span>
            <span className="text-white">{order.event.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/40">Total</span>
            <span className="text-white">{formatMoney(Number(order.totalAmount))}</span>
          </div>
        </div>

        <div className="flex flex-col gap-3 pt-4">
          {order.paymentStatus === "APPROVED" ? (
            <Link href="/dashboard/ingressos" className={primaryButtonClass}>
              Ver meus ingressos
            </Link>
          ) : order.paymentStatus === "PENDING" ? (
            <Link href="/dashboard/pedidos" className={primaryButtonClass}>
              Ver meus pedidos
            </Link>
          ) : (
            <Link href={`/eventos/${order.event.slug}/comprar`} className={primaryButtonClass}>
              Tentar novamente
            </Link>
          )}
          <Link href="/" className={ghostButtonClass}>
            Voltar à home
          </Link>
        </div>
      </div>
    </main>
  );
}

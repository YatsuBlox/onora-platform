import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { EventForm } from "@/components/admin/event-form";

type EditEventPageProps = { params: { id: string } };

export default async function EditEventPage({ params }: EditEventPageProps) {
  const event = await prisma.event.findUnique({
    where: { id: params.id },
    include: { batches: { orderBy: { createdAt: "asc" } } },
  });

  if (!event) notFound();

  return <EventForm mode="edit" initialEvent={event} />;
}

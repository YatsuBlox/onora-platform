import Link from "next/link";
import { PlusCircle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { EventVisual } from "@/components/events/event-visual";
import { formatDateFull } from "@/lib/format";
import { primaryButtonClass } from "@/components/ui/buttons";

export const dynamic = "force-dynamic";

const statusLabel: Record<string, string> = {
  DRAFT: "rascunho",
  ACTIVE: "ativo",
  FINISHED: "finalizado",
  CANCELED: "cancelado",
};

export default async function AdminEventsPage() {
  const events = await prisma.event.findMany({
    orderBy: { date: "desc" },
    include: { batches: true },
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-10">
        <h1 className="font-display text-3xl text-white">Eventos</h1>
        <Link href="/admin/eventos/novo" className={`${primaryButtonClass} px-5 py-2.5`}>
          <PlusCircle className="w-4 h-4" /> Criar evento
        </Link>
      </div>

      {events.length === 0 && <p className="text-white/30 text-sm">Nenhum evento cadastrado ainda.</p>}

      <div className="space-y-0">
        {events.map((event) => (
          <Link
            key={event.id}
            href={`/admin/eventos/${event.id}`}
            className="flex flex-wrap items-center justify-between gap-4 py-5 border-b border-white/10 hover:bg-white/5 transition-colors -mx-2 px-2"
          >
            <div className="flex items-center gap-4">
              <div className="relative w-16 h-11 overflow-hidden shrink-0 border border-white/10">
                <EventVisual seed={event.id} bannerUrl={event.bannerUrl} />
              </div>
              <div>
                <div className="text-white text-[15px]">{event.name}</div>
                <div className="text-xs text-white/35">
                  {formatDateFull(event.date)} · {event.batches.length} lote(s)
                </div>
              </div>
            </div>
            <span className="text-[11px] uppercase tracking-[0.12em] text-white/60">
              {statusLabel[event.status]}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}

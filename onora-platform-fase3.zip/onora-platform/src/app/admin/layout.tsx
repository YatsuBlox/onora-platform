import type { ReactNode } from "react";
import Link from "next/link";
import { Calendar } from "lucide-react";
import { requireAdmin } from "@/lib/session";
import { Wordmark } from "@/components/ui/wordmark";
import { ghostButtonClass } from "@/components/ui/buttons";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  // Dupla proteção: o middleware já bloqueia /admin/* sem sessão de admin,
  // mas repetimos a checagem aqui (com acesso ao banco) para o caso de a
  // sessão ter sido revogada depois que o middleware validou só o token.
  await requireAdmin();

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
          <Wordmark />
          <Link href="/" className={ghostButtonClass}>
            Voltar ao site
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 md:px-8 pt-28 pb-24 grid md:grid-cols-[200px_1fr] gap-8 md:gap-16">
        <div>
          <div className="mb-2 text-[11px] uppercase tracking-[0.15em] text-white/40">
            Painel administrativo
          </div>
          <div className="mb-8 text-[11px] text-white/25 leading-relaxed">
            Vendas, ingressos e dashboard chegam nas próximas fases.
          </div>
          <nav>
            <Link
              href="/admin/eventos"
              className="flex items-center gap-3 py-2.5 text-[13px] uppercase tracking-wide text-white border-l-2 border-white pl-4"
            >
              <Calendar className="w-4 h-4" /> Eventos
            </Link>
          </nav>
        </div>

        <div>{children}</div>
      </div>
    </div>
  );
}

"use client";

import { Suspense, useState, type FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Wordmark } from "@/components/ui/wordmark";
import { Field } from "@/components/ui/field";
import { PrimaryButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";

function ResetPasswordForm() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Não foi possível redefinir a senha.");
        return;
      }
      setDone(true);
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  if (!token) {
    return (
      <p className="text-sm text-white/50">
        Link inválido — falta o token de redefinição. Peça um novo link em{" "}
        <Link href="/recuperar-senha" className="text-white hover:underline">
          recuperar senha
        </Link>
        .
      </p>
    );
  }

  if (done) {
    return (
      <div className="space-y-6">
        <p className="text-sm text-white/60">Senha redefinida com sucesso.</p>
        <Link href="/entrar" className="text-sm text-white hover:underline">
          Ir para o login
        </Link>
      </div>
    );
  }

  return (
    <form className="space-y-5" onSubmit={handleSubmit}>
      <Field
        label="Nova senha"
        type="password"
        required
        minLength={8}
        autoComplete="new-password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Mínimo 8 caracteres, com letra e número"
      />
      <FormError message={error} />
      <PrimaryButton type="submit" className="w-full mt-2" disabled={loading}>
        {loading ? "Salvando..." : "Redefinir senha"}
      </PrimaryButton>
    </form>
  );
}

export default function ResetPasswordPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-24">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="font-display text-xl text-white mt-8">Redefinir senha</h1>
        <p className="text-sm text-white/40 mt-1 mb-8">Escolha uma nova senha para sua conta</p>
        <Suspense fallback={null}>
          <ResetPasswordForm />
        </Suspense>
      </div>
    </main>
  );
}

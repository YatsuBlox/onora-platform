"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { Wordmark } from "@/components/ui/wordmark";
import { Field } from "@/components/ui/field";
import { PrimaryButton, GhostButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";

export default function RecoverPasswordPage() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "Não foi possível processar o pedido.");
        return;
      }
      setSent(true);
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-24">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="font-display text-xl text-white mt-8">Recuperar senha</h1>
        <p className="text-sm text-white/40 mt-1 mb-8">Enviaremos um link de redefinição</p>

        {sent ? (
          <div className="space-y-6">
            <p className="text-sm text-white/60">
              Se <strong className="text-white">{email}</strong> estiver cadastrado, você
              receberá um link de redefinição em instantes. Confira também a caixa de spam.
            </p>
            <Link href="/entrar">
              <GhostButton className="w-full">Voltar ao login</GhostButton>
            </Link>
          </div>
        ) : (
          <form className="space-y-5" onSubmit={handleSubmit}>
            <Field
              label="E-mail"
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@email.com"
            />
            <FormError message={error} />
            <PrimaryButton type="submit" className="w-full mt-2" disabled={loading}>
              {loading ? "Enviando..." : "Enviar link"}
            </PrimaryButton>
          </form>
        )}
      </div>
    </main>
  );
}

"use client";

import { Suspense, useState, type FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Wordmark } from "@/components/ui/wordmark";
import { Field } from "@/components/ui/field";
import { PrimaryButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/dashboard";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Não foi possível entrar.");
        return;
      }

      router.push(redirectTo);
      router.refresh();
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full max-w-sm">
      <Wordmark />
      <h1 className="font-display text-xl text-white mt-8">Entrar na sua conta</h1>
      <p className="text-sm text-white/40 mt-1 mb-8">Acesse seus ingressos e pedidos</p>

      <form className="space-y-5" onSubmit={handleSubmit}>
        <Field
          label="E-mail"
          type="email"
          required
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="voce@email.com"
        />
        <Field
          label="Senha"
          type="password"
          required
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
        />
        <FormError message={error} />
        <Link
          href="/recuperar-senha"
          className="block text-xs text-white/40 hover:text-white transition-colors"
        >
          Esqueci minha senha
        </Link>
        <PrimaryButton type="submit" className="w-full mt-2" disabled={loading}>
          {loading ? "Entrando..." : "Entrar"}
        </PrimaryButton>
      </form>

      <p className="text-center text-sm text-white/40 mt-8">
        Não tem conta?{" "}
        <Link href="/criar-conta" className="text-white hover:underline">
          Criar conta
        </Link>
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-24">
      <Suspense fallback={null}>
        <LoginForm />
      </Suspense>
    </main>
  );
}

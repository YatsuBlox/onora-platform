"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Wordmark } from "@/components/ui/wordmark";
import { Field } from "@/components/ui/field";
import { PrimaryButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";

export default function SignupPage() {
  const router = useRouter();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [cpf, setCpf] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, phone, cpf, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Não foi possível criar a conta.");
        return;
      }

      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-24">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="font-display text-xl text-white mt-8">Criar conta</h1>
        <p className="text-sm text-white/40 mt-1 mb-8">Leva menos de um minuto</p>

        <form className="space-y-5" onSubmit={handleSubmit}>
          <Field
            label="Nome completo"
            required
            autoComplete="name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Seu nome completo"
          />
          <Field
            label="E-mail"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="voce@email.com"
          />
          <Field
            label="Telefone"
            required
            autoComplete="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(00) 00000-0000"
          />
          <Field
            label="CPF"
            required
            inputMode="numeric"
            value={cpf}
            onChange={(e) => setCpf(e.target.value)}
            placeholder="000.000.000-00"
          />
          <Field
            label="Senha"
            type="password"
            required
            autoComplete="new-password"
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Mínimo 8 caracteres, com letra e número"
          />
          <FormError message={error} />
          <PrimaryButton type="submit" className="w-full mt-2" disabled={loading}>
            {loading ? "Criando conta..." : "Criar conta"}
          </PrimaryButton>
        </form>

        <p className="text-center text-sm text-white/40 mt-8">
          Já tem conta?{" "}
          <Link href="/entrar" className="text-white hover:underline">
            Entrar
          </Link>
        </p>
      </div>
    </main>
  );
}

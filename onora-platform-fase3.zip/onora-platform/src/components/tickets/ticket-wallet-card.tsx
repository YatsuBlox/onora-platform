import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { formatDateFull } from "@/lib/format";

type TicketWalletCardProps = {
  ticket: {
    id: string;
    code: string;
    status: "VALID" | "USED" | "CANCELED";
    holderName: string;
    eventName: string;
    venue: string;
    date: Date;
    batchName: string;
  };
  qrDataUrl?: string;
};

const statusLabel: Record<string, string> = {
  VALID: "válido",
  USED: "utilizado",
  CANCELED: "cancelado",
};

export function TicketWalletCard({ ticket, qrDataUrl }: TicketWalletCardProps) {
  const valid = ticket.status === "VALID";

  return (
    <Link
      href={`/dashboard/ingressos/${ticket.id}`}
      className="group flex border border-white/12 hover:border-white/30 transition-colors duration-300"
    >
      <div className="flex-1 p-5 md:p-6">
        <span className="text-[11px] uppercase tracking-[0.12em] text-white/60">
          {statusLabel[ticket.status]}
        </span>
        <div className="font-display text-2xl text-white mt-2 mb-3">{ticket.eventName}</div>
        <div className="text-sm text-white/45 space-y-0.5">
          <div>{ticket.holderName}</div>
          <div>
            {formatDateFull(ticket.date)} · {ticket.venue}
          </div>
          <div className="text-white/30">{ticket.batchName}</div>
        </div>
      </div>
      <div className="relative w-28 md:w-36 flex items-center justify-center border-l border-dashed border-white/15 shrink-0">
        {qrDataUrl ? (
          // eslint-disable-next-line @next/next/no-img-element -- data URL gerada no servidor, não um asset otimizável
          <img
            src={qrDataUrl}
            alt=""
            className={`w-16 h-16 md:w-20 md:h-20 ${valid ? "" : "opacity-40 grayscale"}`}
          />
        ) : (
          <ArrowUpRight className="w-4 h-4 text-white/30 group-hover:text-white/70 transition-colors" />
        )}
      </div>
    </Link>
  );
}

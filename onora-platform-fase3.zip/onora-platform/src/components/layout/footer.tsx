import { Wordmark } from "@/components/ui/wordmark";

export function Footer() {
  return (
    <footer className="border-t border-white/10 mt-28">
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <Wordmark size="text-base" />
        <div className="text-[11px] uppercase tracking-[0.14em] text-white/30">
          © {new Date().getFullYear()} ONORA produções — todos os direitos reservados
        </div>
      </div>
    </footer>
  );
}

import { getAuthPayload } from "@/lib/session";
import { HeaderClient } from "@/components/layout/header-client";

export async function Header() {
  const payload = await getAuthPayload();
  return <HeaderClient loggedIn={!!payload} isAdmin={payload?.role === "ADMIN"} />;
}

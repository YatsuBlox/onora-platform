"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Menu, X } from "lucide-react";
import { Wordmark } from "@/components/ui/wordmark";
import { primaryButtonClass } from "@/components/ui/buttons";

type HeaderClientProps = {
  loggedIn: boolean;
  isAdmin: boolean;
};

export function HeaderClient({ loggedIn, isAdmin }: HeaderClientProps) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/90 backdrop-blur-md border-b border-white/10"
          : "bg-gradient-to-b from-black/70 to-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
        <Link href="/">
          <Wordmark />
        </Link>
        <nav className="hidden md:flex items-center gap-10 text-[13px] uppercase tracking-[0.1em] text-white/60">
          <Link href="/" className="hover:text-white transition-colors">
            Eventos
          </Link>
          {loggedIn ? (
            <>
              <Link href="/dashboard" className="hover:text-white transition-colors">
                Minha conta
              </Link>
              {isAdmin && (
                <Link href="/admin/eventos" className="hover:text-white transition-colors">
                  Admin
                </Link>
              )}
              <button onClick={handleLogout} className="text-white/40 hover:text-white transition-colors">
                Sair
              </button>
            </>
          ) : (
            <>
              <Link href="/entrar" className="hover:text-white transition-colors">
                Entrar
              </Link>
              <Link href="/criar-conta" className={primaryButtonClass}>
                Criar conta
              </Link>
            </>
          )}
        </nav>
        <button className="md:hidden text-white" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-black border-t border-white/10 px-5 py-6 flex flex-col gap-5 text-sm uppercase tracking-wide">
          <Link href="/" className="text-white/80" onClick={() => setOpen(false)}>
            Eventos
          </Link>
          {loggedIn ? (
            <>
              <Link href="/dashboard" className="text-white/80" onClick={() => setOpen(false)}>
                Minha conta
              </Link>
              {isAdmin && (
                <Link href="/admin/eventos" className="text-white/80" onClick={() => setOpen(false)}>
                  Admin
                </Link>
              )}
              <button
                className="text-left text-white/40"
                onClick={() => {
                  setOpen(false);
                  handleLogout();
                }}
              >
                Sair
              </button>
            </>
          ) : (
            <>
              <Link href="/entrar" className="text-white/80" onClick={() => setOpen(false)}>
                Entrar
              </Link>
              <Link href="/criar-conta" className="text-white" onClick={() => setOpen(false)}>
                Criar conta
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}

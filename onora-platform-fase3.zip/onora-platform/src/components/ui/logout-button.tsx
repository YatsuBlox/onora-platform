"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { GhostButton } from "@/components/ui/buttons";

export function LogoutButton() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleLogout() {
    setLoading(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <GhostButton onClick={handleLogout} disabled={loading}>
      {loading ? "Saindo..." : "Sair"}
    </GhostButton>
  );
}

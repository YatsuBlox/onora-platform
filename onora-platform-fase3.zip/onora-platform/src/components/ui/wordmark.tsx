export function Wordmark({ size = "text-2xl" }: { size?: string }) {
  return (
    <span className={`font-display ${size} tracking-[0.14em] text-white select-none`}>
      ONORA<span className="text-white/40">·</span>
    </span>
  );
}

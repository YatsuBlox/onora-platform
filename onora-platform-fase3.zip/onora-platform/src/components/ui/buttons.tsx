import type { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement>;

export const primaryButtonClass =
  "inline-flex items-center justify-center gap-2 bg-white text-black px-6 py-3.5 text-[13px] font-medium tracking-[0.04em] uppercase transition-all duration-200 hover:bg-white/90 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none";

export const ghostButtonClass =
  "inline-flex items-center justify-center gap-2 border border-white/20 text-white px-6 py-3.5 text-[13px] font-medium tracking-[0.04em] uppercase transition-all duration-200 hover:border-white/50 active:scale-[0.98]";

export function PrimaryButton({ className = "", children, ...props }: ButtonProps) {
  return (
    <button className={`${primaryButtonClass} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function GhostButton({ className = "", children, ...props }: ButtonProps) {
  return (
    <button className={`${ghostButtonClass} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function TextLink({ className = "", children, ...props }: ButtonProps) {
  return (
    <button
      className={`text-[13px] tracking-wide text-white/50 hover:text-white transition-colors duration-200 border-b border-transparent hover:border-white/40 pb-0.5 ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

export function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="border-l-2 border-red-400/60 pl-3 py-1 text-sm text-red-300">{message}</div>
  );
}

export function FormSuccess({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="border-l-2 border-emerald-400/60 pl-3 py-1 text-sm text-emerald-300">
      {message}
    </div>
  );
}

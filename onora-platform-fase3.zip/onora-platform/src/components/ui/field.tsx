import type { InputHTMLAttributes } from "react";

type FieldProps = InputHTMLAttributes<HTMLInputElement> & {
  label: string;
};

export function Field({ label, className = "", ...props }: FieldProps) {
  return (
    <label className="block">
      <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-2">
        {label}
      </span>
      <input
        className={`w-full bg-transparent border-b border-white/15 py-3 text-[15px] text-white placeholder-white/25 focus:outline-none focus:border-white/70 transition-colors duration-200 ${className}`}
        {...props}
      />
    </label>
  );
}

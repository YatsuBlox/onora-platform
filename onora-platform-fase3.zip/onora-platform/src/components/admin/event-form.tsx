"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { Field } from "@/components/ui/field";
import { PrimaryButton, GhostButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";
import { EventVisual } from "@/components/events/event-visual";
import { toDateTimeLocalValue } from "@/lib/format";

type BatchDraft = {
  id?: string;
  name: string;
  price: string;
  totalQuantity: string;
  soldQuantity?: number;
};

type EventFormProps = {
  mode: "create" | "edit";
  initialEvent?: {
    id: string;
    name: string;
    tagline: string | null;
    description: string | null;
    bannerUrl: string | null;
    date: Date;
    venue: string;
    address: string | null;
    attractions: string[];
    info: string | null;
    status: "DRAFT" | "ACTIVE" | "FINISHED" | "CANCELED";
    isHero: boolean;
    batches: { id: string; name: string; price: unknown; totalQuantity: number; soldQuantity: number }[];
  };
};

const statusOptions: { value: "DRAFT" | "ACTIVE" | "FINISHED" | "CANCELED"; label: string }[] = [
  { value: "DRAFT", label: "Rascunho" },
  { value: "ACTIVE", label: "Ativo" },
  { value: "FINISHED", label: "Finalizado" },
  { value: "CANCELED", label: "Cancelado" },
];

export function EventForm({ mode, initialEvent }: EventFormProps) {
  const router = useRouter();

  const [name, setName] = useState(initialEvent?.name ?? "");
  const [tagline, setTagline] = useState(initialEvent?.tagline ?? "");
  const [description, setDescription] = useState(initialEvent?.description ?? "");
  const [bannerUrl, setBannerUrl] = useState(initialEvent?.bannerUrl ?? "");
  const [date, setDate] = useState(
    initialEvent ? toDateTimeLocalValue(initialEvent.date) : ""
  );
  const [venue, setVenue] = useState(initialEvent?.venue ?? "");
  const [address, setAddress] = useState(initialEvent?.address ?? "");
  const [info, setInfo] = useState(initialEvent?.info ?? "");
  const [status, setStatus] = useState<"DRAFT" | "ACTIVE" | "FINISHED" | "CANCELED">(
    initialEvent?.status ?? "DRAFT"
  );
  const [isHero, setIsHero] = useState(initialEvent?.isHero ?? false);
  const [attractions, setAttractions] = useState<string[]>(
    initialEvent?.attractions.length ? initialEvent.attractions : [""]
  );
  const [batches, setBatches] = useState<BatchDraft[]>(
    initialEvent?.batches.length
      ? initialEvent.batches.map((b) => ({
          id: b.id,
          name: b.name,
          price: String(b.price),
          totalQuantity: String(b.totalQuantity),
          soldQuantity: b.soldQuantity,
        }))
      : [{ name: "", price: "", totalQuantity: "" }]
  );

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function updateAttraction(index: number, value: string) {
    setAttractions((prev) => prev.map((a, i) => (i === index ? value : a)));
  }
  function addAttraction() {
    setAttractions((prev) => [...prev, ""]);
  }
  function removeAttraction(index: number) {
    setAttractions((prev) => prev.filter((_, i) => i !== index));
  }

  function updateBatch(index: number, field: keyof BatchDraft, value: string) {
    setBatches((prev) => prev.map((b, i) => (i === index ? { ...b, [field]: value } : b)));
  }
  function addBatch() {
    setBatches((prev) => [...prev, { name: "", price: "", totalQuantity: "" }]);
  }
  function removeBatch(index: number) {
    setBatches((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    const payload = {
      name,
      tagline,
      description,
      bannerUrl,
      date,
      venue,
      address,
      attractions: attractions.map((a) => a.trim()).filter(Boolean),
      info,
      status,
      isHero,
      batches: batches
        .filter((b) => b.name.trim())
        .map((b) => ({
          id: b.id,
          name: b.name,
          price: b.price,
          totalQuantity: b.totalQuantity,
        })),
    };

    try {
      const url = mode === "create" ? "/api/admin/events" : `/api/admin/events/${initialEvent!.id}`;
      const method = mode === "create" ? "POST" : "PATCH";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Não foi possível salvar o evento.");
        return;
      }

      router.push(`/admin/eventos/${data.event.id}`);
      router.refresh();
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  const selectClass =
    "w-full bg-transparent border-b border-white/15 py-3 text-[15px] text-white focus:outline-none focus:border-white/60";
  const smallInputClass =
    "bg-transparent border-b border-white/15 py-2.5 text-sm text-white placeholder-white/25 focus:outline-none focus:border-white/60";

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-10 pb-10">
      <h1 className="font-display text-3xl text-white">
        {mode === "create" ? "Criar evento" : "Editar evento"}
      </h1>

      <div>
        <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-3">
          Banner do evento
        </span>
        <div className="relative aspect-[16/7] overflow-hidden border border-white/10 mb-3">
          <EventVisual seed={initialEvent?.id ?? "novo-evento"} bannerUrl={bannerUrl || null} />
        </div>
        <Field
          label="URL do banner"
          type="url"
          value={bannerUrl}
          onChange={(e) => setBannerUrl(e.target.value)}
          placeholder="https://..."
        />
        <p className="text-xs text-white/30 mt-2">
          Cole a URL de uma imagem já hospedada (ex: um link do seu storage).
          Upload direto de arquivo chega em uma fase futura.
        </p>
      </div>

      <div className="space-y-6">
        <Field label="Nome do evento" value={name} onChange={(e) => setName(e.target.value)} required />
        <Field
          label="Descrição curta"
          value={tagline}
          onChange={(e) => setTagline(e.target.value)}
          placeholder="Uma linha sobre o evento"
        />
        <label className="block">
          <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-2">
            Descrição completa
          </span>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full bg-transparent border-b border-white/15 py-3 text-[15px] text-white placeholder-white/25 focus:outline-none focus:border-white/60 resize-none"
          />
        </label>
        <Field
          label="Data e horário"
          type="datetime-local"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
        <Field label="Local" value={venue} onChange={(e) => setVenue(e.target.value)} required />
        <Field label="Endereço" value={address} onChange={(e) => setAddress(e.target.value)} />

        <label className="block">
          <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-2">Status</span>
          <select value={status} onChange={(e) => setStatus(e.target.value as typeof status)} className={selectClass}>
            {statusOptions.map((opt) => (
              <option key={opt.value} value={opt.value} className="bg-black">
                {opt.label}
              </option>
            ))}
          </select>
          <span className="block text-xs text-white/30 mt-2">
            Eventos em rascunho não aparecem publicamente.
          </span>
        </label>

        <label className="flex items-center gap-3 text-sm text-white/70">
          <input
            type="checkbox"
            checked={isHero}
            onChange={(e) => setIsHero(e.target.checked)}
            className="w-4 h-4 accent-white"
          />
          Destacar como evento principal da home
        </label>
      </div>

      <div>
        <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-3">Atrações</span>
        <div className="space-y-3">
          {attractions.map((attraction, i) => (
            <div key={i} className="flex items-center gap-3">
              <input
                value={attraction}
                onChange={(e) => updateAttraction(i, e.target.value)}
                placeholder={`Atração ${i + 1}`}
                className="flex-1 bg-transparent border-b border-white/15 py-2.5 text-[15px] text-white placeholder-white/25 focus:outline-none focus:border-white/60"
              />
              <button type="button" onClick={() => removeAttraction(i)} className="text-white/25 hover:text-white/70">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
        <GhostButton type="button" onClick={addAttraction} className="mt-3 px-4 py-2 text-[11px]">
          + Adicionar atração
        </GhostButton>
      </div>

      <label className="block">
        <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-2">
          Informações importantes
        </span>
        <textarea
          value={info}
          onChange={(e) => setInfo(e.target.value)}
          rows={3}
          placeholder="Ex: evento 18+, política de entrada, itens não permitidos..."
          className="w-full bg-transparent border-b border-white/15 py-3 text-[15px] text-white placeholder-white/25 focus:outline-none focus:border-white/60 resize-none"
        />
      </label>

      <div>
        <span className="block text-[11px] uppercase tracking-[0.12em] text-white/40 mb-3">
          Lotes, preços e quantidade disponível
        </span>
        <div className="space-y-5">
          {batches.map((batch, i) => (
            <div key={batch.id ?? `new-${i}`} className="pb-5 border-b border-white/10">
              <div className="grid grid-cols-[1fr_1fr_1fr_auto] gap-3 items-center">
                <input
                  value={batch.name}
                  onChange={(e) => updateBatch(i, "name", e.target.value)}
                  placeholder="Nome do lote"
                  className={smallInputClass}
                />
                <input
                  value={batch.price}
                  onChange={(e) => updateBatch(i, "price", e.target.value)}
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="Preço (R$)"
                  className={smallInputClass}
                />
                <input
                  value={batch.totalQuantity}
                  onChange={(e) => updateBatch(i, "totalQuantity", e.target.value)}
                  type="number"
                  min={batch.soldQuantity ?? 0}
                  placeholder="Quantidade"
                  className={smallInputClass}
                />
                <button
                  type="button"
                  onClick={() => removeBatch(i)}
                  disabled={!!batch.soldQuantity}
                  className="text-white/25 hover:text-white/70 disabled:opacity-20 disabled:pointer-events-none"
                  title={batch.soldQuantity ? "Não é possível remover: já tem ingressos vendidos" : "Remover lote"}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              {!!batch.soldQuantity && (
                <div className="text-xs text-white/30 mt-2">
                  {batch.soldQuantity} já vendidos — a quantidade não pode ficar abaixo disso
                </div>
              )}
            </div>
          ))}
        </div>
        <GhostButton type="button" onClick={addBatch} className="mt-3 px-4 py-2 text-[11px]">
          + Adicionar lote
        </GhostButton>
      </div>

      <FormError message={error} />

      <div className="flex gap-3 pt-4">
        <GhostButton type="button" onClick={() => router.push("/admin/eventos")}>
          Cancelar
        </GhostButton>
        <PrimaryButton type="submit" className="flex-1" disabled={loading}>
          {loading ? "Salvando..." : mode === "create" ? "Criar evento" : "Salvar alterações"}
        </PrimaryButton>
      </div>
    </form>
  );
}

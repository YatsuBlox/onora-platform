"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Field } from "@/components/ui/field";
import { PrimaryButton, GhostButton } from "@/components/ui/buttons";
import { FormError } from "@/components/ui/form-message";
import { formatMoney } from "@/lib/format";

type Batch = { id: string; name: string; price: number; available: number };

type Holder = { name: string; phone: string; email: string };

type CheckoutFlowProps = {
  eventId: string;
  eventName: string;
  eventSlug: string;
  batches: Batch[];
};

export function CheckoutFlow({ eventId, eventName, eventSlug, batches }: CheckoutFlowProps) {
  const [step, setStep] = useState<"select" | "holders" | "payment">("select");
  const [batchId, setBatchId] = useState(batches[0]?.id ?? "");
  const [quantity, setQuantity] = useState(1);
  const [holders, setHolders] = useState<Holder[]>([{ name: "", phone: "", email: "" }]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const batch = batches.find((b) => b.id === batchId);
  const total = batch ? batch.price * quantity : 0;
  const maxQuantity = Math.min(8, batch?.available ?? 1);

  function goToHolders() {
    setHolders((prev) =>
      Array.from({ length: quantity }, (_, i) => prev[i] ?? { name: "", phone: "", email: "" })
    );
    setStep("holders");
  }

  function updateHolder(index: number, field: keyof Holder, value: string) {
    setHolders((prev) => prev.map((h, i) => (i === index ? { ...h, [field]: value } : h)));
  }

  async function handleFinish(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId,
          batchId,
          holders: holders.map((h) => ({ name: h.name, phone: h.phone, email: h.email || undefined })),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Não foi possível iniciar o pagamento.");
        setLoading(false);
        return;
      }

      // Redireciona de verdade para o checkout hospedado pelo Mercado Pago.
      window.location.href = data.redirectUrl;
    } catch {
      setError("Erro de conexão. Tente novamente.");
      setLoading(false);
    }
  }

  const steps = ["select", "holders", "payment"];

  return (
    <div className="max-w-xl mx-auto px-6 pt-28 pb-24">
      <Link
        href={`/eventos/${eventSlug}`}
        className="flex items-center gap-1.5 text-[13px] uppercase tracking-wide text-white/40 hover:text-white mb-10 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Cancelar
      </Link>

      <div className="flex items-center gap-2 mb-10">
        {steps.map((s) => (
          <div
            key={s}
            className={`h-[2px] flex-1 transition-colors duration-500 ${
              steps.indexOf(step) >= steps.indexOf(s) ? "bg-white" : "bg-white/10"
            }`}
          />
        ))}
      </div>

      <h1 className="font-display text-3xl text-white mb-10">{eventName}</h1>

      {step === "select" && (
        <div className="space-y-10">
          <div>
            <span className="block text-[11px] uppercase tracking-[0.15em] text-white/40 mb-4">Lote</span>
            <div className="space-y-0">
              {batches.map((b) => {
                const active = batchId === b.id;
                const soldOut = b.available <= 0;
                return (
                  <button
                    key={b.id}
                    type="button"
                    disabled={soldOut}
                    onClick={() => {
                      setBatchId(b.id);
                      setQuantity(1);
                    }}
                    className={`w-full flex items-center justify-between py-4 border-b transition-colors text-left ${
                      active ? "border-white text-white" : "border-white/10 text-white/60"
                    } ${soldOut ? "opacity-30" : ""}`}
                  >
                    <div>
                      <div className="text-[15px]">{b.name}</div>
                      <div className="text-[12px] text-white/35">
                        {soldOut ? "esgotado" : `${b.available} disponíveis`}
                      </div>
                    </div>
                    <div className="text-[15px] tabular-nums">{formatMoney(b.price)}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <span className="block text-[11px] uppercase tracking-[0.15em] text-white/40 mb-4">Quantidade</span>
            <div className="flex items-center gap-6">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-9 h-9 border border-white/20 text-white/70 hover:border-white/50 transition-colors"
              >
                −
              </button>
              <span className="text-xl text-white w-6 text-center tabular-nums">{quantity}</span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(maxQuantity, q + 1))}
                className="w-9 h-9 border border-white/20 text-white/70 hover:border-white/50 transition-colors"
              >
                +
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-white/10 pt-6">
            <span className="text-sm text-white/40">Total</span>
            <span className="text-2xl text-white font-display tabular-nums">{formatMoney(total)}</span>
          </div>

          <PrimaryButton className="w-full" onClick={goToHolders} disabled={!batch || batch.available <= 0}>
            Continuar
          </PrimaryButton>
        </div>
      )}

      {step === "holders" && (
        <div className="space-y-8">
          <p className="text-sm text-white/45">
            Cada ingresso é individual e intransferível — preencha os dados de cada titular.
          </p>
          {holders.map((h, i) => (
            <div key={i} className="space-y-5 pb-8 border-b border-white/10">
              <div className="text-[11px] uppercase tracking-[0.15em] text-white/40">
                Ingresso {String(i + 1).padStart(2, "0")}
              </div>
              <Field
                label="Nome completo"
                value={h.name}
                onChange={(e) => updateHolder(i, "name", e.target.value)}
                placeholder="Nome do titular"
                required
              />
              <Field
                label="Telefone / WhatsApp"
                value={h.phone}
                onChange={(e) => updateHolder(i, "phone", e.target.value)}
                placeholder="(00) 00000-0000"
                required
              />
              <Field
                label="E-mail (opcional)"
                type="email"
                value={h.email}
                onChange={(e) => updateHolder(i, "email", e.target.value)}
                placeholder="titular@email.com"
              />
            </div>
          ))}
          <div className="flex gap-3">
            <GhostButton type="button" onClick={() => setStep("select")}>
              Voltar
            </GhostButton>
            <PrimaryButton type="button" className="flex-1" onClick={() => setStep("payment")}>
              Ir para pagamento
            </PrimaryButton>
          </div>
        </div>
      )}

      {step === "payment" && (
        <form onSubmit={handleFinish} className="space-y-8">
          <div className="space-y-3 pb-6 border-b border-white/10">
            <div className="flex justify-between text-sm text-white/50">
              <span>
                {quantity}x {batch?.name}
              </span>
              <span>{formatMoney(total)}</span>
            </div>
            <div className="flex justify-between text-lg text-white pt-2">
              <span>Total</span>
              <span className="font-display">{formatMoney(total)}</span>
            </div>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-[#009EE3] hover:bg-[#0090cc] text-white py-4 text-[13px] uppercase tracking-[0.05em] font-medium transition-colors disabled:opacity-50"
          >
            {loading ? "Redirecionando..." : "Pagar com Mercado Pago"}
          </button>
          <FormError message={error} />
          <p className="text-xs text-white/30 text-center">
            Você será redirecionado para o ambiente seguro do Mercado Pago para concluir o
            pagamento. Seus ingressos ficam disponíveis em &quot;Meus ingressos&quot; assim que o
            pagamento for confirmado.
          </p>
          <GhostButton type="button" className="w-full" onClick={() => setStep("holders")}>
            Voltar
          </GhostButton>
        </form>
      )}
    </div>
  );
}

function hashStringToInt(value: string): number {
  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = (hash * 31 + value.charCodeAt(i)) % 100000;
  }
  return hash;
}

type EventVisualProps = {
  seed: string; // normalmente o id do evento
  bannerUrl?: string | null;
  className?: string;
};

// Sem hooks/estado — funciona tanto em Server Components (páginas públicas)
// quanto em Client Components (formulário do admin).
export function EventVisual({ seed, bannerUrl, className = "" }: EventVisualProps) {
  if (bannerUrl) {
    return (
      <div className={`absolute inset-0 overflow-hidden ${className}`}>
        {/* eslint-disable-next-line @next/next/no-img-element -- banners vêm de URLs externas arbitrárias cadastradas pelo admin */}
        <img src={bannerUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ boxShadow: "inset 0 0 160px 40px rgba(0,0,0,0.35)" }} />
      </div>
    );
  }

  const n = hashStringToInt(seed);
  const a = n % 100;
  const b = (n * 53) % 100;

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`}>
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(155deg, #050505 0%, #161616 45%, #060606 100%)" }}
      />
      <div
        className="absolute w-[70%] h-[140%] opacity-[0.16] blur-[90px]"
        style={{
          background: "linear-gradient(180deg, rgba(255,255,255,0.9), transparent 70%)",
          left: `${a - 10}%`,
          top: "-25%",
          transform: `rotate(${16 + (n % 10)}deg)`,
        }}
      />
      <div
        className="absolute w-[55%] h-[130%] opacity-[0.10] blur-[90px]"
        style={{
          background: "linear-gradient(180deg, rgba(255,255,255,0.8), transparent 70%)",
          left: `${b}%`,
          top: "-20%",
          transform: `rotate(-${10 + (n % 14)}deg)`,
        }}
      />
      <div
        className="absolute rounded-full opacity-[0.20] blur-[100px]"
        style={{
          width: "70%",
          height: "70%",
          left: `${20 + (n % 30)}%`,
          bottom: "-25%",
          background: "radial-gradient(circle, rgba(255,255,255,0.9), transparent 70%)",
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage: "radial-gradient(rgba(255,255,255,0.9) 1px, transparent 1px)",
          backgroundSize: "26px 26px",
        }}
      />
      <div className="absolute inset-0" style={{ boxShadow: "inset 0 0 160px 40px rgba(0,0,0,0.55)" }} />
      <div className="absolute bottom-3 right-3 text-[9px] uppercase tracking-[0.15em] text-white/25">
        Sem banner cadastrado
      </div>
    </div>
  );
}

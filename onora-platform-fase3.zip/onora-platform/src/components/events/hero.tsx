import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { EventVisual } from "@/components/events/event-visual";
import { formatDateFull, formatTime } from "@/lib/format";
import { primaryButtonClass, ghostButtonClass } from "@/components/ui/buttons";

type HeroProps = {
  event: {
    id: string;
    slug: string;
    name: string;
    tagline: string | null;
    date: Date;
    venue: string;
    bannerUrl: string | null;
  };
};

export function Hero({ event }: HeroProps) {
  return (
    <section className="relative h-[88vh] min-h-[620px] max-h-[920px] w-full overflow-hidden">
      <EventVisual seed={event.id} bannerUrl={event.bannerUrl} />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-black/5" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/40" />

      <div className="relative h-full max-w-7xl mx-auto px-5 md:px-8 flex flex-col justify-end pb-16 md:pb-24">
        <div className="text-[11px] uppercase tracking-[0.25em] text-white/50 mb-5">
          Próximo evento
        </div>
        <h1 className="font-display uppercase text-[13vw] leading-[0.9] md:text-[6rem] md:leading-[0.88] text-white tracking-tight mb-6 max-w-4xl break-words">
          {event.name}
        </h1>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mb-4 text-white/55 text-sm">
          <span>{formatDateFull(event.date)}</span>
          <span className="hidden md:inline text-white/20">/</span>
          <span>{formatTime(event.date)}</span>
          <span className="hidden md:inline text-white/20">/</span>
          <span>{event.venue}</span>
        </div>
        {event.tagline && <p className="text-white/55 max-w-md mb-9 text-[15px]">{event.tagline}</p>}
        <div className="flex flex-wrap gap-3">
          <Link href={`/eventos/${event.slug}`} className={primaryButtonClass}>
            Ver ingressos <ArrowUpRight className="w-4 h-4" />
          </Link>
          <Link href={`/eventos/${event.slug}`} className={ghostButtonClass}>
            Ver detalhes
          </Link>
        </div>
      </div>
    </section>
  );
}

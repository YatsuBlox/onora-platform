import Link from "next/link";
import { EventVisual } from "@/components/events/event-visual";
import { formatDateShort } from "@/lib/format";

type EventCardProps = {
  event: {
    id: string;
    slug: string;
    name: string;
    date: Date;
    venue: string;
    status: string;
    bannerUrl: string | null;
  };
};

export function EventCard({ event }: EventCardProps) {
  return (
    <Link href={`/eventos/${event.slug}`} className="group block">
      <div className="relative aspect-[4/5] md:aspect-[3/4] overflow-hidden mb-4">
        <div className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-[1.06]">
          <EventVisual seed={event.id} bannerUrl={event.bannerUrl} />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
        <div className="absolute bottom-5 left-5 right-5">
          <div className="text-[11px] uppercase tracking-[0.14em] text-white/60 mb-1.5">
            {formatDateShort(event.date)}
          </div>
          <div className="font-display text-2xl md:text-3xl text-white leading-[0.95]">
            {event.name}
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between text-sm text-white/55">
        <span>{event.venue}</span>
      </div>
    </Link>
  );
}

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { slugify } from "../src/lib/slug";

const prisma = new PrismaClient();

async function seedAdmin() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? "admin@onora.com.br";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "TrocarSenha123";

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      fullName: "Administrador ONORA",
      email: adminEmail,
      phone: "(00) 00000-0000",
      cpf: "00000000000",
      passwordHash,
      role: "ADMIN",
    },
  });

  console.log("Usuário admin pronto:");
  console.log(`  e-mail: ${admin.email}`);
  console.log(`  senha:  ${adminPassword}  (troque assim que fizer o primeiro login)`);
}

// Eventos de EXEMPLO, só para testar o catálogo com dados reais no banco.
// Apague-os pelo painel admin quando os eventos de verdade forem
// cadastrados.
async function seedExampleEvents() {
  const events = [
    {
      name: "Evento exemplo 01",
      tagline: "Descrição curta cadastrada pelo administrador para este evento",
      date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30), // daqui a 30 dias
      venue: "Nome do local",
      address: "Endereço do local — cidade, estado",
      attractions: ["Atração 01", "Atração 02", "Atração 03"],
      info: "Informações importantes do evento, definidas pelo administrador no cadastro.",
      status: "ACTIVE" as const,
      isHero: true,
      batches: [
        { name: "1º lote", price: 90, totalQuantity: 300 },
        { name: "2º lote", price: 120, totalQuantity: 400 },
        { name: "VIP", price: 280, totalQuantity: 100 },
      ],
    },
    {
      name: "Evento exemplo 02",
      tagline: "Descrição curta cadastrada pelo administrador para este evento",
      date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 60), // daqui a 60 dias
      venue: "Nome do local",
      address: "Endereço do local — cidade, estado",
      attractions: ["Atração 01", "Atração 02"],
      info: "Informações importantes do evento, definidas pelo administrador no cadastro.",
      status: "ACTIVE" as const,
      isHero: false,
      batches: [
        { name: "Inteira", price: 150, totalQuantity: 800 },
        { name: "Meia-entrada", price: 75, totalQuantity: 300 },
      ],
    },
    {
      name: "Evento exemplo 03 (encerrado)",
      tagline: "Edição encerrada — mantida no histórico",
      date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 40), // 40 dias atrás
      venue: "Nome do local",
      address: "Endereço do local — cidade, estado",
      attractions: ["Atração 01"],
      info: "Evento encerrado.",
      status: "FINISHED" as const,
      isHero: false,
      batches: [{ name: "Lote único", price: 60, totalQuantity: 400 }],
    },
  ];

  for (const eventData of events) {
    const { batches, ...rest } = eventData;
    const slug = slugify(rest.name);

    await prisma.event.upsert({
      where: { slug },
      update: {},
      create: {
        ...rest,
        slug,
        batches: { create: batches },
      },
    });
  }

  console.log(`${events.length} eventos de exemplo prontos (edite/apague pelo painel admin).`);
}

async function main() {
  await seedAdmin();
  await seedExampleEvents();
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
